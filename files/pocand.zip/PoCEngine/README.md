PoC Engine version 0.1
Christian Michael Baum

PoC Engine is a 2.5d engine . Currently, it uses AndEngine and only works for Android devices, but I plan to move from AndEngine to SDL so that it can be ported to Windows, Mac, Linux and iOS

I abbreviate Punching Out Cthulhu as PoC for an inside joke, but it's not something that's hard to understand.

I took a lot of the code from a game I'm working on and stripped the "game" from it to make this engine public.

NOTE: This current version is just an inital public commit to get things going. A lot of the code is a mess because of the way I seperated the game from the engine.