package xian.baum.punchingoutcthulhu;

import java.io.IOException;

import org.anddev.andengine.audio.sound.Sound;
import org.anddev.andengine.audio.sound.SoundFactory;
import org.anddev.andengine.engine.Engine;
import org.anddev.andengine.opengl.texture.TextureOptions;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlasTextureRegionFactory;
import org.anddev.andengine.util.Debug;

import android.content.Context;

class Music
{
	Sound song;
	Engine engine;
	Context context;
	int Music[][] = new int[50][3];//50 things of 4.5 second samples of 3 instruments playing at the same time!
	void loadMusic(int SongNumber)
	{
	switch (SongNumber)
	{
	case 0:
		Music[0][0]=1;
		Music[0][1]=2;
		Music[1][0]=4;
		Music[1][1]=5;
		Music[2][0]=1;
		Music[2][1]=2;
		Music[4][0]=4;
		Music[4][1]=5;
		
	break;
	case 1:
		Music[0][0]=1;
		Music[0][1]=2;
		Music[0][0]=1;
		Music[0][1]=2;
		Music[0][0]=1;
		Music[0][1]=2;
		Music[0][0]=1;
		Music[0][1]=2;
		Music[0][0]=1;
		Music[0][1]=2;
	break;
	}
		SoundFactory.setAssetBasePath("mfx/");
		for(int x=0;x>50;x++)
		{
			if(x==0)
				break;
			for(int y=0;y>3;y++)
		{
				if(y==0)
					break;
		try {
			this.song = SoundFactory.createSoundFromAsset(this.engine.getSoundManager(), this.context, Music+".ogg");
		} catch (final IOException e) {
			Debug.e(e);
		}
		}
		}
		
	}
	void PlaySound()
	{
		song.play();
	}
	void StopSound()
	{
		song.stop();
	}
}
