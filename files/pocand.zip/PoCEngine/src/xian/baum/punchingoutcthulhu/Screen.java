package xian.baum.punchingoutcthulhu;

public class Screen {

}
