package xian.baum.punchingoutcthulhu;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.anddev.andengine.entity.scene.background.AutoParallaxBackground;
import org.anddev.andengine.entity.sprite.Sprite;
import org.anddev.andengine.extension.svg.opengl.texture.atlas.bitmap.SVGBitmapTextureAtlasTextureRegionFactory;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BuildableBitmapTextureAtlas;
import org.anddev.andengine.opengl.texture.region.BaseTextureRegion;
import org.anddev.andengine.opengl.texture.region.TextureRegion;

import android.content.Context;
import android.util.FloatMath;

public class Background 
{
//ParallaxEntity BG;
AutoParallaxBackground BG;
Sprite sprite;
String path;
int width,
	height,
	imageHeight,
	imageWidth,
	ZIndex=0;
boolean parallax,
	ground;
float scale;
private TextureRegion texture;
private BuildableBitmapTextureAtlas textureAtlas;
BaseTextureRegion baseTextureRegion;
TextureRegion textureRegion;

Background(int bgType, int cameraWidth, int cameraHeight, int videoOptions,
		Context context)
{
	switch (bgType)
	{
	case 1:
		path="sky.svg";
	break;
	case 2:
		ground = true;
		parallax = true;
		path="ground.svg";
		ZIndex=1;
	break;
	case 3:
		parallax = true;
		path="full.svg";
	break;
	}
	this.imageWidth = CameraState.roundToPowerOfTwo
			(this.width, videoOptions);
	this.imageHeight = CameraState.roundToPowerOfTwo
			(this.height, videoOptions);
	this.loadTexture(context);
}

void update(float playerX, float playerY, float playerZ,
		float playerAngle, float radius, int cameraHeight, int degree)
{
	if(ground)
		sprite.setPosition
			(0,cameraHeight-sprite.getHeight()+5+(playerZ*(degree/2)));
	if(parallax)
		BG.setParallaxValue((int)(playerAngle*degree)+90);
	sprite.setZIndex(this.ZIndex);
	this.sprite.setScale((float) getScale(playerX,playerY,playerAngle,radius));	
}

void loadTexture(Context context)
{
	this.texture = 
		SVGBitmapTextureAtlasTextureRegionFactory.createFromAsset
		(this.textureAtlas, context, this.path, this.imageWidth, 
				this.imageHeight);
//	baseTextureRegion = this.texture;
	textureRegion = texture;//(TextureRegion)baseTextureRegion;
	this.sprite = new Sprite (0,0,this.width,this.height, textureRegion);
}



public static double getScale
	(float playerX, float playerY, float playerAngle, double radius) {
	Point pointA = new Point(playerX,playerY);
	double pointBX = Math.cos(Math.toRadians(playerAngle))*20000;
	double pointBY = Math.sin(Math.toRadians(playerAngle))*20000;
	Point pointB = new Point(pointBX,pointBY);
	Point center = new Point(0,0);
	double baX = pointB.x - pointA.x;
    double baY = pointB.y - pointA.y;
    double caX = center.x - pointA.x;
    double caY = center.y - pointA.y;

    double a = baX * baX + baY * baY;
    double bBy2 = baX * caX + baY * caY;
    double c = caX * caX + caY * caY - radius * radius;

    double pBy2 = bBy2 / a;
    double q = c / a;

    double disc = pBy2 * pBy2 - q;
    if (disc < 0) {
     return 0;
    }
    // if disc == 0 ... dealt with later
    double tmpSqrt = Math.sqrt(disc);
    double abScalingFactor1 = -pBy2 + tmpSqrt;
    double abScalingFactor2 = -pBy2 - tmpSqrt;

    Point p1 = new Point(pointA.x - baX * abScalingFactor1, pointA.y
            - baY * abScalingFactor1);
    if (disc == 0) { // abScalingFactor1 == abScalingFactor2
        //then good
    }
    int quadrant=0;
    //different function practically
    float a1=0,b=0,testAngle=0,tanThingy=0,distance=0;
	if(p1.x==playerX&&p1.y>playerY){quadrant=4;testAngle=90; distance=(float) (p1.y-playerY);}
	if(p1.x<playerX&&p1.y==playerY){quadrant=5;testAngle=0;  distance=(float) (playerX-p1.x);}
	if(p1.x==playerX&&p1.y<playerY){quadrant=6;testAngle=270;distance=(float) (playerY-p1.y);}
	if(p1.x>playerX&&p1.y==playerY){quadrant=7;testAngle=180;distance=(float) (p1.x-playerX);}
	if(playerX==p1.x&&playerY==p1.y){quadrant=8;distance=0;testAngle=0;}
	if(p1.x<playerX&&p1.y>playerY){quadrant=0;a1=(float) (p1.y-playerY);b=(float) (playerX-p1.x);tanThingy=a1/b;}
	if(p1.x>playerX&&p1.y>playerY){quadrant=1;a1=(float) (p1.y-playerY);b=(float) (p1.x-playerX);tanThingy=b/a1;}
	if(p1.x>playerX&&p1.y<playerY){quadrant=2;a1=(float) (playerY-p1.y);b=(float) (p1.x-playerX);tanThingy=a1/b;}
	if(p1.x<playerX&&p1.y<playerY){quadrant=3;a1=(float) (playerY-p1.y);b=(float) (playerX-p1.x);tanThingy=b/a1;}
	if(quadrant==0||quadrant==1||quadrant==2||quadrant==3){
		testAngle = (float)(Math.toDegrees(Math.atan(tanThingy))+(quadrant*90));
		distance = FloatMath.sqrt((a1*a1)+(b*b));}
	return distance/(2*radius);
}



static class Point {
    double x, y;

    public Point(double x, double y) { this.x = x; this.y = y; }

    @Override
    public String toString() {
        return "Point [x=" + x + ", y=" + y + "]";
    }
}


}