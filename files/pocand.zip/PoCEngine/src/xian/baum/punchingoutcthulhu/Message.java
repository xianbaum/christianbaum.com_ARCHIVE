package xian.baum.punchingoutcthulhu;

import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.text.Text;
import org.anddev.andengine.opengl.font.Font;

public class Message {
private String message;
public Text text;
private int X,
	Y;
final String END_OF_LINE="/n";

boolean shouldBeNull=false;
Message(int messageType, int X, int Y)
{

//Strings (I broke this, will fix later)
	
//String tempString = R.getResourceByName("strings.txt");
//return tempString.exec("|"+messagetype,END_OF_LINE);
//TODO: Probably a lot more is needed,
//or if all else fails, copy the strings directly into here:
//String format will be Name: Message.
//They should adapt to the window by themselves when it's complete
//String string = "";
//----------------END OF STRINGS--------------

X = this.X;
Y = this.Y;
}

void drawText(Scene scene, Font font)
{
	text = new Text(X,Y, font,this.message);
	scene.attachChild(text);
}

void removeText(Scene scene)
{
	scene.detachChild(text);
	shouldBeNull=true;
}

boolean getShouldBeNull()
{
	return shouldBeNull;
}

}
