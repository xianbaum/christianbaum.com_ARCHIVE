package xian.baum.punchingoutcthulhu;

public enum State {
    WAITING (0),
    DEAD (1),
    EVAIDING (2),
    PUNCHR (3),
    PUNCHL (4),
    PUNCHS (5),
    ACTIONA (6),
    ACTIONB (7),
    ACTIONC (8),
    CHASING (9),
    FLEEING (10);
    
    private final int stateNumber;   
    State(int state) {
        this.stateNumber = state;
    }
    
    public int i() { 
        return stateNumber; 
    }
}