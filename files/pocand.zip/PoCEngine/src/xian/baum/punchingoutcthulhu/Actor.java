package xian.baum.punchingoutcthulhu;
import org.anddev.andengine.entity.scene.Scene;

import android.content.Context;
import android.util.FloatMath;
import android.util.Log;

class Actor
{
Limb limb[] = new Limb[5];
int health=100,
	moveInstruction,
	equationUsed=0,
	instruction;
State state;
float
	X=0,
	Y=0,
	Z=0,
	targetX=0,
	targetY=0,
	targetZ=0,
	ZVelocity=0,
	distance=0,
	anglePlayer=0,
	angle=0,
	velocity=0,
	time,
	targetTime,
	timer=0,
	punchTimer;
boolean isAtTarget=true,
	isRightHand=false,
	isPunching=false,
	isPlayer=false;
int enemyType;

void calcDistance(float playerX, float playerY)
{	
	float a=0,
		b=0,
		tanThingy=0,
		quadrant=0;
	if(playerX==this.X&&playerY>this.Y){quadrant=4;this.anglePlayer=90; this.distance=playerY-this.Y;}
	if(playerX<this.X&&playerY==this.Y){quadrant=5;this.anglePlayer=0;  this.distance=this.X-playerX;}
	if(playerX==this.X&&playerY<this.Y){quadrant=6;this.anglePlayer=270;this.distance=this.Y-playerY;}
	if(playerX>this.X&&playerY==this.Y){quadrant=7;this.anglePlayer=180;this.distance=playerX-this.X;}
	if(this.X==playerX&&this.Y==playerY){quadrant=8;this.distance=0;this.anglePlayer=0;}
	if(playerX<this.X&&playerY>this.Y){quadrant=0;a=playerY-this.Y;b=this.X-playerX;tanThingy=a/b;}
	if(playerX>this.X&&playerY>this.Y){quadrant=1;a=playerY-this.Y;b=playerX-this.X;tanThingy=b/a;}
	if(playerX>this.X&&playerY<this.Y){quadrant=2;a=this.Y-playerY;b=playerX-this.X;tanThingy=a/b;}
	if(playerX<this.X&&playerY<this.Y){quadrant=3;a=this.Y-playerY;b=this.X-playerX;tanThingy=b/a;}
	if(quadrant==0||quadrant==1||quadrant==2||quadrant==3)
	{
		this.anglePlayer = (float)(Math.toDegrees(Math.atan(tanThingy))+(quadrant*90));
		this.distance = FloatMath.sqrt((a*a)+(b*b));
	}
}

void calcOnScreen(float playerAngle)
//This section calculates the screen position.Broken. Testing stuff.
{
	float wrapLeft=0, wrapRight=0;
	if(playerAngle-90<0)
		wrapRight=(playerAngle-90)+360;
	if(playerAngle+90>360)
		wrapLeft=(playerAngle+90)-360;
	if(this.anglePlayer>playerAngle-90&&this.anglePlayer<playerAngle+90)
		this.equationUsed=1;
	else if(wrapLeft!=0&&this.anglePlayer<wrapLeft)
		this.equationUsed=2;
	else if(wrapRight!=0&&this.anglePlayer>wrapRight)
		this.equationUsed=3;
	else
		this.equationUsed=0;
}

void actorUpdater(float playerX, float playerY, float playerZ, float playerAngle, boolean isPunching, float touchX, float touchY,
	int CameraWidth, int CameraHeight, Scene scene){
	this.calcDistance(playerX, playerY);
	this.checkAngle();
	this.calcOnScreen(playerAngle);
	for(int i=0;i<=5;++i)
	{
		if (this.limb[i] == null)
			break;
		this.limb[i].calcZIndex((int)this.distance);
		this.limb[i].setisBeingPunched(this.limb[i].calcIsBeingPunched(isPunching, touchX, touchY));
		this.limb[i].calcScale(this.distance);
		this.limb[i].calcOnScreenLocation(playerAngle, this.anglePlayer, playerZ, this.Z, this.equationUsed, CameraWidth, CameraHeight);
	}
	for(int i=0;i<=5;++i)
	{
		if (this.limb[i] == null)
			break;
		this.limb[i].setSprite(scene);
	}
}

void checkAngle()
{
	if(this.angle>=360)
		this.angle-=360;
	if(this.angle<0)
		this.angle+=360;
}

void calcGo(float targetX, float targetY, float targetZ, float time, boolean timeBased) //false = relative velocity true = rel time
{
	float a=0;
	float b=0;
	float tanThingy=0,
			quadrant=0;
	targetX+=this.X;
	targetY+=this.Y;
	targetZ+=this.Z;
	this.targetX=targetX;
	this.targetY=targetY;
	this.targetZ=targetZ;
	if(this.X==targetX&&this.Y>targetY){quadrant=4;this.angle=90; this.distance=this.Y-targetY;}
	if(this.X<targetX&&this.Y==targetY){quadrant=5;this.angle=0;  this.distance=targetX-this.X;}
	if(this.X==targetX&&this.Y<targetY){quadrant=6;this.angle=270;this.distance=targetY-this.Y;}
	if(this.X>targetX&&this.Y==targetY){quadrant=7;this.angle=180;this.distance=this.X-targetX;}
	if(targetX==this.X&&targetY==this.Y){quadrant=8;this.distance=0;this.angle=0;}
	if(this.X<targetX&&this.Y>targetY){quadrant=0;a=this.Y-targetY;b=targetX-this.X;tanThingy=a/b;}
	if(this.X>targetX&&this.Y>targetY){quadrant=1;a=this.Y-targetY;b=this.X-targetX;tanThingy=b/a;}
	if(this.X>targetX&&this.Y<targetY){quadrant=2;a=targetY-this.Y;b=this.X-targetX;tanThingy=a/b;}
	if(this.X<targetX&&this.Y<targetY){quadrant=3;a=targetY-this.Y;b=targetX-this.X;tanThingy=b/a;}
	if(quadrant==0||quadrant==1||quadrant==2||quadrant==3){
		this.angle = (float)(Math.toDegrees(Math.atan(tanThingy))+(quadrant*90));
		this.distance = FloatMath.sqrt((a*a)+(b*b));}
	if(timeBased)
	{
		this.velocity = (this.distance/time)*0.02f;
		this.ZVelocity=(targetZ/time)*0.02f;
	}
	if(!timeBased)
	{
		this.velocity = time;
		this.ZVelocity=(targetZ/time)*this.velocity;
	}
}

boolean checkIsAtTarget(float targetX, float targetY, float targetZ, boolean timeBased)
{
	if(!timeBased)
	{
		float a=0,
				b=0,
				tanThingy=0,
				quadrant=0;
		if(this.X==targetX&&this.Y>targetY){quadrant=4;this.angle=90; this.distance=this.Y-targetY;}
		if(this.X<targetX&&this.Y==targetY){quadrant=5;this.angle=0;  this.distance=targetX-this.X;}
		if(this.X==targetX&&this.Y<targetY){quadrant=6;this.angle=270;this.distance=targetY-this.Y;}
		if(this.X>targetX&&this.Y==targetY){quadrant=7;this.angle=180;this.distance=this.X-targetX;}
		if(targetX==this.X&&targetY==this.Y){quadrant=8;this.distance=0;this.angle=0;}
		if(this.X<targetX&&this.Y>targetY){quadrant=0;a=this.Y-targetY;b=targetX-this.X;tanThingy=a/b;}
		if(this.X>targetX&&this.Y>targetY){quadrant=1;a=this.Y-targetY;b=this.X-targetX;tanThingy=b/a;}
		if(this.X>targetX&&this.Y<targetY){quadrant=2;a=targetY-this.Y;b=this.X-targetX;tanThingy=a/b;}
		if(this.X<targetX&&this.Y<targetY){quadrant=3;a=targetY-this.Y;b=targetX-this.X;tanThingy=b/a;}
		if(quadrant==0||quadrant==1||quadrant==2||quadrant==3){
			this.angle = (float)(Math.toDegrees(Math.atan(tanThingy))+(quadrant*90));
			this.distance = FloatMath.sqrt((a*a)+(b*b));}
		if (this.distance<this.velocity+.01f)// This should work well, but if the velocity it too high, then this might be too far
		{
			this.isAtTarget=true;
			if(targetX!=0)
				this.X=this.targetX;
			if(targetY!=0)
				this.Y=this.targetY;
			if(targetZ!=0)
				this.Z=targetZ;
			return true;}
	}
	if(timeBased)
	{
		if(this.time>=this.targetTime)
		{
			if(targetX!=0)
				this.X=this.targetX;
			if(targetY!=0)
				this.Y=this.targetY;
			if(targetZ!=0)
				this.Z=targetZ;
			this.isAtTarget=true;
			return true;
		}
	}
	this.isAtTarget=false;
	return false;
	
}


void go()
{
	this.Z +=this.ZVelocity;
	this.X += Math.cos(Math.toRadians(this.angle))*this.velocity;
	this.Y -= Math.sin(Math.toRadians(this.angle))*this.velocity;
}

void go(int offset)
{
	this.Z +=this.ZVelocity;
	this.X += Math.cos(Math.toRadians(this.angle+offset))*this.velocity;
	this.Y -= Math.sin(Math.toRadians(this.angle+offset))*this.velocity;
}

void modifyLimb(int No, int instructionTemp, float XTemp, float YTemp, float growthTemp, float rotationTemp, float alphaTemp, float timeTemp, boolean isTimeBased)
{
	this.limb[No].modifyLimb(instructionTemp, XTemp,YTemp,growthTemp, rotationTemp, alphaTemp, timeTemp, isTimeBased);
}

void enemyAI(int instruction, float X, float Y, float Z, float time, boolean isTimeBased)
{
	if(this.instruction==instruction)
	{
		if(this.isAtTarget)
		{
			this.calcGo(X, Y, Z, time, isTimeBased); //false = relative velocity true = rel time
			this.isAtTarget=false;
		}
		if(this.checkIsAtTarget(X,Y,Z,isTimeBased))
			this.instruction++;
		else
			this.go();
		this.time+=.02f;
	}
}

void loopLimb(int limb, int instructionStart, int instructionEnd)
{
	this.limb[limb].loopLimb(instructionStart, instructionEnd);
}

void loopEnemy(int instructionStart, int instructionEnd)
{
	if(this.instruction==instructionStart)
		this.instruction=instructionEnd;
}

void moveLimb(int no, int inst, float x, float y,float time)
{
	modifyLimb(no,inst,x,y,0,0,1,time,true);
}

void limbAlpha(int no, int inst, float alpha, float time)
{
	modifyLimb(no,inst,0,0,0,0,alpha,time,true);
}

void limbRotate(int no, int inst, float rotate, float time)
{
	modifyLimb(no,inst,0,0,0,rotate,1,time,true);
}

void limbGrow(int no, int inst, float grow, float time)
{
	modifyLimb(no,inst,0,0,grow,0,1,time,true);
}

Actor (int type, int gX, int gY, int gZ,int cameraWidth,int cameraHeight,int videoOptions,Context context)
{//TODO literally every enemy in the game
	this.enemyType= type;
	switch (type) {
	case 1:
	{
		limb[0] = new Limb(1,cameraWidth, cameraHeight,videoOptions,context);
		limb[1] = new Limb(2,cameraWidth, cameraHeight,videoOptions,context);
		limb[2] = new Limb(3,cameraWidth, cameraHeight,videoOptions,context);
	}
	break;

	}
	this.X = gX;
	this.Y = gY;
	this.Z = gZ;
}

void Move(int moveType)
{	//TODO literally every move in the game
	switch(moveType)
	{
	case 1:
		
	break;
	}
}

//gettors and settors

float getX()
{
	return X;
}

float getY()
{
	return Y;
}

float getZ()
{
	return Z;
}

float getAngle()
{
	return angle;
}

}
