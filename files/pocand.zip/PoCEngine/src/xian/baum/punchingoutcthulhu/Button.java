package xian.baum.punchingoutcthulhu;

public class Button extends Message {
int width;
int height;
	Button(int messageType, int X, int Y) {
		super(messageType, X, Y);
		
	}

}
