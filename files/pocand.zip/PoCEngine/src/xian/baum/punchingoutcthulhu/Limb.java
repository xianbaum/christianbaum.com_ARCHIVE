package xian.baum.punchingoutcthulhu;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.util.FloatMath;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.sprite.Sprite;
import org.anddev.andengine.extension.svg.opengl.texture.atlas.bitmap.SVGBitmapTextureAtlasTextureRegionFactory;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BuildableBitmapTextureAtlas;
import org.anddev.andengine.opengl.texture.region.BaseTextureRegion;
import org.anddev.andengine.opengl.texture.region.TextureRegion;

class Limb
{
Sprite sprite;
private float
	health=100,
	X=0,
	Y=0,
	velocity=1,
	scale=0,
	distance=0,
	angle=0,
	growth=0,
	rotation=0,
	alpha=1f,
	growthVelocity=0,
	rotationVelocity=0,
	alphaVelocity=0,
	targetGrowth=0,
	targetRotation=0,
	targetAlpha=0,
	targetX=0,
	targetY=0,
	time=0,
	targetTime;
private boolean
	scales=true,
	isAttached=false,
	isOnScreen=false,
	isAtTarget=true,
	isBeingPunched=false,
	flipped=false,
	vflipped=false,
	hasHealth=false;
private int
	localZIndex,
	width=8,
	height=8,
	imageWidth=8,
	imageHeight=8,
	XOnScreen = 0,
	YOnScreen = 0,
	ZIndex = 0,
	instruction=0;
private TextureRegion texture;
private BuildableBitmapTextureAtlas textureAtlas;
BaseTextureRegion baseTextureRegion;
TextureRegion textureRegion;
String path = "eskull.svg";
int limbType;

//sprite and texture stuffstuff


Limb(int limbType, int cameraWidth, int cameraHeight, int videoOptions, Context context)
{
	//Might be unnecessary
	this.limbType = limbType;
	
	//Defines the properties based on the limbtype
	switch(limbType)
	{
	case 1:
		path= "eskull.svg";
		this.width = 178*(cameraWidth/854);
		this.height = 172*(cameraHeight/480);
		this.X = 0;
		this.Y = -15;
	break;
	case 2:
		path= "eskull-fist.svg";
		this.width = 178*(cameraWidth/854);
		this.height = 172*(cameraHeight/480);
		this.X = 0;
		this.Y = 15;
		this.setFlipped();
	break;
	case 3:
		path= "eskull-fist.svg";
		this.width = 178*(cameraWidth/854);
		this.height = 172*(cameraHeight/480);
		this.X = 0;
		this.Y = 15;
	break;
	case 4:
		width = 200*(cameraWidth/854);
		height = 128*(cameraHeight/480);
		X=15;
		path= "eskull.svg";
	case 5:
		path= "eskull.svg";
		width = 200*(cameraWidth/854);
		height = 128*(cameraHeight/480);
		X=-15;
	break;
	case 6:
		localZIndex = 1;
		height = 128*(cameraHeight/480);
		width = 200*(cameraWidth/854);
	break; 
	}
	
	//Sprite & texture stuff. Rounds images to power of two, then loads them
	this.imageWidth = CameraState.roundToPowerOfTwo(this.width, videoOptions);
	this.imageHeight = CameraState.roundToPowerOfTwo(this.height, videoOptions);
	this.loadTexture(context);
}

void loadTexture(Context context)
{
	this.texture = SVGBitmapTextureAtlasTextureRegionFactory.createFromAsset(this.textureAtlas, context, this.path, this.imageWidth, this.imageHeight);
//	baseTextureRegion = this.texture;
	textureRegion = texture;//(TextureRegion)baseTextureRegion;
	this.sprite = new Sprite (0,0,this.width,this.height, textureRegion);
}

void calcOnScreenLocation(final float playerAngle, final float enemyAngleToPlayer, final float playerZ, final float enemyZ,
		final int equationUsed, final int cameraWidth, final int cameraHeight)
{
	switch(equationUsed)
	{
	case 0:
		this.isOnScreen=false;
	break;
	case 1:
		this.isOnScreen=true;
		this.XOnScreen=(int) ((playerAngle-enemyAngleToPlayer)*(cameraWidth/90)+(cameraWidth*.5f));
	break;
	case 2:
		this.isOnScreen=true;
		this.XOnScreen=(int) ((playerAngle-(enemyAngleToPlayer+360))*(cameraWidth/90)+(cameraWidth*.5f));
	break;
	case 3:
		this.isOnScreen=true;
		this.XOnScreen=(int) ((playerAngle-(enemyAngleToPlayer-360))*(cameraWidth/90)+(cameraWidth*.5f));
	break;
	}
	this.YOnScreen = (int)(((playerZ-enemyZ)*(cameraWidth/90))+(cameraHeight*.5f)/*+((.5f*cameraHeight)/enemyDistance)*/);

	//Here, it scales the limbs.
	int testX = (int)(this.X*(cameraWidth/90));
	int testY = (int)(this.Y*(cameraWidth/90));
	this.XOnScreen = XOnScreen+((int) ((testX*this.scale)));
	this.YOnScreen = YOnScreen+((int) ((testY*this.scale)));
}

void calcScale(final float enemyDistance)
{
	if(this.scales)
	{
		float apparentWidth = (float) ((180/Math.PI)*(this.width/(enemyDistance)));
		this.scale = apparentWidth/this.sprite.getWidth();
	}
}

void calcZIndex(final int tempDistance)
{
	this.setZIndex(((int)(100000-tempDistance))+localZIndex);
}

void setSprite(Scene scene)
{
	if(!this.isOnScreen&&this.isAttached)
	{
		scene.detachChild(this.sprite);
		this.isAttached=false;
	}
	if (this.isOnScreen&&!this.isAttached)
	{	
		scene.attachChild(this.sprite);
//		scene.setOnSceneTouchListener(this.sprite);
		this.isAttached=true;
	}
	this.sprite.setZIndex(this.ZIndex);
	this.sprite.setPosition(this.XOnScreen-(this.sprite.getWidth()/2),this.YOnScreen-(this.sprite.getHeight()/2));
	if(scales)
		this.sprite.setScale(this.scale+(this.getGrowth()*this.scale));
	this.sprite.setRotation(this.rotation);
	this.sprite.setBlendFunction(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA);
	this.sprite.setAlpha(this.alpha);
}

// Moving Limb stuff

void calcGo(final float targetX, final float targetY, final float targetGrowth, final float targetRotation,
		final float targetAlpha, final float time, final boolean timeBased)
{
	float a=0;
	float b=0;
	float tanThingy=0,
			quadrant=0;
	this.targetAlpha=targetAlpha;
	this.targetTime=time+this.time;;
	this.targetGrowth=targetGrowth+this.getGrowth();
	this.targetRotation=targetRotation+this.rotation;
	this.targetX=targetX+this.X;
	this.targetY=targetY+this.Y;
	if(rotation>=360)
		this.angle-=360;
	if(this.X==targetX&&this.Y>targetY){quadrant=4;this.angle=90; this.distance=this.Y-targetY;}
	if(this.X<targetX&&this.Y==targetY){quadrant=5;this.angle=0;  this.distance=targetX-this.X;}
	if(this.X==targetX&&this.Y<targetY){quadrant=6;this.angle=270;this.distance=targetY-this.Y;}
	if(this.X>targetX&&this.Y==targetY){quadrant=7;this.angle=180;this.distance=this.X-targetX;}
	if(targetX==this.X&&targetY==this.Y){quadrant=8;this.distance=0;this.angle=0;}
	if(this.X<targetX&&this.Y>targetY){quadrant=0;a=this.Y-targetY;b=targetX-this.X;tanThingy=a/b;}
	if(this.X>targetX&&this.Y>targetY){quadrant=1;a=this.Y-targetY;b=this.X-targetX;tanThingy=b/a;}
	if(this.X>targetX&&this.Y<targetY){quadrant=2;a=targetY-this.Y;b=this.X-targetX;tanThingy=a/b;}
	if(this.X<targetX&&this.Y<targetY){quadrant=3;a=targetY-this.Y;b=targetX-this.X;tanThingy=b/a;}
	if(quadrant==0||quadrant==1||quadrant==2||quadrant==3){
		this.angle = (float)(Math.toDegrees(Math.atan(tanThingy))+(quadrant*90));
		this.distance = FloatMath.sqrt((a*a)+(b*b));}
	if(timeBased)
	{
		this.velocity = (this.distance/time)*0.02f;
		this.rotationVelocity=(targetRotation/time)*0.02f;
		this.growthVelocity=(targetGrowth/time)*0.02f;
		this.alphaVelocity=((targetAlpha-alpha)/time)*0.02f;
	}
	if(!timeBased)
	{
		this.velocity = time*.02f;
		this.alphaVelocity=(((targetAlpha-alpha)/time)*this.velocity)*.02f;
		this.rotationVelocity=((targetRotation/time)*this.velocity)*.02f;
		this.growthVelocity=((targetGrowth/time)*this.velocity)*.02f;
	}
}

boolean checkIsAtTarget(final float targetX,final float targetY, final float targetGrowth, final float targetRotation,
		final boolean timeBased)
{
	if(!timeBased)
	{
		float a=0,
				b=0,
				tanThingy=0,
				quadrant=0;
		if(this.X==targetX&&this.Y>targetY){quadrant=4;this.angle=90; this.distance=this.Y-targetY;}
		if(this.X<targetX&&this.Y==targetY){quadrant=5;this.angle=0;  this.distance=targetX-this.X;}
		if(this.X==targetX&&this.Y<targetY){quadrant=6;this.angle=270;this.distance=targetY-this.Y;}
		if(this.X>targetX&&this.Y==targetY){quadrant=7;this.angle=180;this.distance=this.X-targetX;}
		if(targetX==this.X&&targetY==this.Y){quadrant=8;this.distance=0;this.angle=0;}
		if(this.X<targetX&&this.Y>targetY){quadrant=0;a=this.Y-targetY;b=targetX-this.X;tanThingy=a/b;}
		if(this.X>targetX&&this.Y>targetY){quadrant=1;a=this.Y-targetY;b=this.X-targetX;tanThingy=b/a;}
		if(this.X>targetX&&this.Y<targetY){quadrant=2;a=targetY-this.Y;b=this.X-targetX;tanThingy=a/b;}
		if(this.X<targetX&&this.Y<targetY){quadrant=3;a=targetY-this.Y;b=targetX-this.X;tanThingy=b/a;}
		if(quadrant==0||quadrant==1||quadrant==2||quadrant==3){
			this.angle = (float)(Math.toDegrees(Math.atan(tanThingy))+(quadrant*90));
			this.distance = FloatMath.sqrt((a*a)+(b*b));}
		if (this.distance<this.velocity+.01f)// This should work well, but if the velocity it too high, then this might look weird.
		{
			this.isAtTarget=true;
			if(targetX!=0)
				this.X=this.targetX;
			if(targetY!=0)
				this.Y=this.targetY;
			if(targetGrowth!=0)
				this.setGrowth(this.targetGrowth);
			if(targetRotation!=0)
				this.rotation=this.targetRotation;
			if(this.targetAlpha!=this.alpha)
				this.targetAlpha=this.alpha;
			return true;}
	}
	if(timeBased)
	{
		if(this.time>=this.targetTime)
		{
			if(targetX!=0)
				this.X=this.targetX;
			if(targetY!=0)
				this.Y=this.targetY;
			if(targetGrowth!=0)
				this.setGrowth(this.targetGrowth);
			if(targetRotation!=0)
				this.rotation=this.targetRotation;
			this.isAtTarget=true;
			return true;
		}
	}
	this.isAtTarget=false;
	return false;
}

void go()
{
	this.alpha+=this.alphaVelocity;
	this.rotation+=this.rotationVelocity;
	this.setGrowth(this.getGrowth() + this.growthVelocity);
	this.X += Math.cos(Math.toRadians(this.angle))*this.velocity;
	this.Y -= Math.sin(Math.toRadians(this.angle))*this.velocity;
}

void modifyLimb(final int instructionTemp, final float XTemp, final float YTemp, final float growthTemp, final float rotationTemp,
		final float alphaTemp, final float timeTemp, final boolean isTimeBased)
{
	if(this.getInstruction()==instructionTemp)
	{
		if(isAtTarget)
		{
			calcGo(XTemp, YTemp, growthTemp, rotationTemp, alphaTemp, timeTemp, isTimeBased); //false = relative velocity true = rel time
			isAtTarget=false;
		}
		if(checkIsAtTarget(XTemp,YTemp,growthTemp,rotationTemp,isTimeBased))
			nextInstruction();
		else
			go();
	this.time+=.02f;
	}
}

void loopLimb(final int instructionStart, final int instructionEnd)
{
	if(this.getInstruction()==instructionStart)
		this.setInstruction(instructionEnd);
}

//Punched stuff

boolean calcIsBeingPunched(final boolean isPunching, final float touchX, final float touchY)
{
	if(isPunching)
	{
/*	if(touchX>=this.XOnScreen&&//-(this.sprite.getWidth()/2)&&
		touchX<=this.XOnScreen+((this.sprite.getWidth()))&&
		touchY>=this.YOnScreen&&//-(this.sprite.getWidth()/2)&&
		touchY<=this.YOnScreen+((this.sprite.getWidth()))&&
		distance<25)*/
	//This code might be buggy. Theory: It does not factor in scale.
	if(touchX>sprite.getX()&&touchX<sprite.getWidth()&&
		touchY>sprite.getY()&&touchY<sprite.getHeight())
	{this.isBeingPunched=true;
		return true;}}
	return false;
}

//Gettors and settors

float getX()
{
	return this.X;
}

float getY()
{
	return this.Y;
}

void setInstruction(final int set)
{
	this.instruction=set;
}

void nextInstruction()
{
	this.setInstruction(this.getInstruction() + 1);
}

void setZIndex(int ZIndex)
{
	this.ZIndex = ZIndex;
}

void setisBeingPunched(final boolean yes)
{
	this.isBeingPunched = yes;
}

void setFlipped()
{
	this.flipped=!this.flipped;
}

void setvFlipped()
{
	this.vflipped=!this.vflipped;
}

void setHasHealth()
{
	this.hasHealth=!this.hasHealth;
}

void loseHealth(final float damage)
{
	this.health-=damage;
}

void gainHealth(final float recovery)
{
	this.health+=recovery;
}

float getHealth()
{
	return this.health;
}

public float getGrowth() {
	return growth;
}

public void setGrowth(float growth) {
	this.growth = growth;
}

public int getInstruction() {
	return instruction;
}

public void setIsAtTarget(boolean isAtTargX)
{
	this.isAtTarget=isAtTargX;
}

}
