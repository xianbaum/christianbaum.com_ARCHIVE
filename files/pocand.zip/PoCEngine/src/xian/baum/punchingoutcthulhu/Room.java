package xian.baum.punchingoutcthulhu;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.sprite.Sprite;

import android.content.Context;

public class Room {
Actor actor[] = new Actor[8]; //Objects
Background BG[] = new Background[3];
float length,//*
	width,//*
	height,//*
	radius,//*
	//Modified after initialized
	scale;//
boolean
	circular;//*
Player player;
void scaleRoom(Player player)
{
	if(circular)
	{
		scale = 2*player.angle;
	}
}

Room(int roomType, int cameraWidth, int cameraHeight, Context context, int videoOptions)
{
	switch (roomType)
	{
	case 1:
		BG[0] = new Background(3, cameraWidth, cameraHeight, 1,context);
		circular = true;
		radius = 300;
	break;
	case 2:
		BG[0] = new Background(1, cameraWidth, cameraHeight,videoOptions,context);
		BG[1] = new Background(2, cameraWidth, cameraHeight,videoOptions,context);
		circular = true;
		radius = 300;
	break;
	}
}

void updateRoom(int degree, int degreeY, int cameraWidth, int cameraHeight,
		float  touchX, float touchY, Scene scene)
{
	for(int x=0;x<=8;x++)
	{
		this.actor[x].actorUpdater(player.X,player.Y,player.Z,player.angle,
			player.isPunching, touchX, touchY, cameraWidth, cameraHeight,
			scene);
	}
	scene.sortChildren();
	for(int x=0;x<=3;x++)
	{
		BG[0].update(player.X,player.Y,player.Z,player.angle,this.radius,cameraWidth,cameraHeight);
	}
}


}
