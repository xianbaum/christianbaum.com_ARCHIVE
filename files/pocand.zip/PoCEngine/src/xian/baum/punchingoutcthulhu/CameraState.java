package xian.baum.punchingoutcthulhu;

import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.sprite.Sprite;

public class CameraState {
private int
	width = 854,
	height = 480,
	maxTextureSize,
	videoSetting,
	degree=854/90,
	degreeY=480/90;
private Sprite fadeSprite;
String fadeSpritePath;
private boolean fadingOut,
	fading;
private float fadeAlpha=0,
	targetAlpha=1f;

//----------fading stuff;
void FadeOut(FadeColor color, Scene scene)
{
	fading=true;
	fadingOut=true;
	switch (color)
	{ 
	case WHITE:
		targetAlpha=1;
		fadeSpritePath = "fade-white.svg";
	break;
	case BLACK:
		targetAlpha=1;
		fadeSpritePath = "fade-black.svg";
	break;
	case BLUE:
		targetAlpha=1;
		fadeSpritePath = "fade-blue.svg";
	break;
	case GREY:
		targetAlpha=.65f;
		fadeSpritePath = "fade-grey.svg";
	break;
	case PURPLE:
		targetAlpha=1;
		fadeSpritePath = "fade-purple.svg";
	break;
	}
}

void FadeIn(Scene scene)
{
	fadingOut=false;
	fading=true;
}

void updateFade(Scene scene)
{
if(fading)
{
	if(fadingOut)
	{
		fadeAlpha+=.01f;
	}
	else
	{
		fadeAlpha-=.01f;
	}
	fadeSprite.setAlpha(fadeAlpha);
	if(!fadingOut&&fadeAlpha<=0f)
	{
		fadeAlpha=0f;
		scene.detachChild(fadeSprite);
		fadeSprite=null;
	}
	else if(fadingOut&&fadeAlpha>=targetAlpha)
	{
		fadeAlpha=targetAlpha;
	}
}
}

//texture stuff

void calcMaxTextureSize()
{
	this.maxTextureSize = 2^this.videoSetting+7;
}

static int roundToPowerOfTwo(int size,int maxTextureSize)
{
	int newSize =(int) Math.ceil(Math.log(size)/Math.log(2));
	if(newSize>maxTextureSize)
		newSize=maxTextureSize;
	return newSize;
}

//Gettors and settors

int getMaxTextureSize()
{
	return maxTextureSize;
}

int getVideoSetting()
{
	return videoSetting;
}

int getCamreaWidth()
{
	return width;
}

int getCameraHeight()
{
	return height;
}

int getDegree()
{
	return degree;
}

boolean isAtTargetAlpha()
{
	if(fadingOut&&fadeAlpha==targetAlpha||!fadingOut&&fadeAlpha==0f)
		return true;
	else
		return false;
}

public int getWidth() {
	return width;
}

public void setWidth(int width) {
	this.width = width;
}

public int getHeight() {
	return height;
}

public void setHeight(int height) {
	this.height = height;
}

public void setDegree(int degree) {
	this.degree = degree;
}

public int getDegreeY() {
	return degreeY;
}

public void setDegreeY(int degreeY) {
	this.degreeY = degreeY;
}

}
