package xian.baum.punchingoutcthulhu;

//import java.io.IOException;
import org.anddev.andengine.engine.Engine;
import org.anddev.andengine.engine.camera.Camera;
import org.anddev.andengine.engine.handler.IUpdateHandler;
import org.anddev.andengine.engine.handler.timer.ITimerCallback;
import org.anddev.andengine.engine.handler.timer.TimerHandler;
import org.anddev.andengine.engine.options.EngineOptions;
import org.anddev.andengine.engine.options.EngineOptions.ScreenOrientation;
import org.anddev.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.scene.Scene.IOnSceneTouchListener;
import org.anddev.andengine.entity.sprite.Sprite;
import org.anddev.andengine.entity.util.FPSLogger;
import org.anddev.andengine.extension.svg.opengl.texture.atlas.bitmap.SVGBitmapTextureAtlasTextureRegionFactory;
import org.anddev.andengine.opengl.font.Font;
import org.anddev.andengine.opengl.font.FontFactory;
import org.anddev.andengine.opengl.texture.ITexture;
import org.anddev.andengine.opengl.texture.TextureOptions;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BuildableBitmapTextureAtlas;
import org.anddev.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.anddev.andengine.opengl.texture.atlas.buildable.builder.BlackPawnTextureBuilder;
import org.anddev.andengine.opengl.texture.atlas.buildable.builder.ITextureBuilder.TextureAtlasSourcePackingException;
import org.anddev.andengine.opengl.texture.bitmap.BitmapTexture.BitmapTextureFormat;
import org.anddev.andengine.opengl.texture.region.BaseTextureRegion;
import org.anddev.andengine.opengl.texture.region.TextureRegion;
import org.anddev.andengine.entity.scene.background.AutoParallaxBackground;
import org.anddev.andengine.entity.scene.background.ParallaxBackground;
import org.anddev.andengine.entity.scene.background.ParallaxBackground.ParallaxEntity;
import org.anddev.andengine.input.touch.TouchEvent;
import org.anddev.andengine.ui.activity.BaseGameActivity;
import org.anddev.andengine.util.Debug;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.WindowManager;
//import org.anddev.andengine.audio.sound.Sound;
//import org.anddev.andengine.audio.sound.SoundFactory;

public class PunchingOutCthulhuActivity extends BaseGameActivity implements IOnSceneTouchListener, KeyEvent.Callback
{

//temporary CameraWidth & height
static int touchMode=0;//0 = unrestricted, 1 can't move, 2 can't spin, 3 punch, 4 menu.
static float touchTimer;
//private Sound mExplosionSound;
World world;
static Sprite G1Sprite;
Actor enemy[] = new Actor[5];
private Camera mCamera;
CameraState cameraState;
private float touchX;
private float touchY;
static float touchX1,
	touchX2,
	touchY1,
	touchY2;

@SuppressWarnings("deprecation")
public Engine onLoadEngine()
{
	Log.v("w","S");
	int Measuredwidth = 0;  
	int Measuredheight = 0;  
	Point size = new Point();
	WindowManager w = getWindowManager();

	if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB){
	      w.getDefaultDisplay().getSize(size);
	      Measuredwidth = size.x;
	      Measuredheight = size.y; 
	    }else{
	      Display d = w.getDefaultDisplay(); 
	      Measuredwidth = d.getWidth(); 
	      Measuredheight = d.getHeight(); 
	    }
	if (Measuredwidth>0&&Measuredheight>0)
	{
		cameraState.setWidth(Measuredwidth);
		cameraState.setHeight(Measuredheight);
	}
	Log.v("h",""+cameraState.getHeight());
	Log.v("w",""+cameraState.getWidth());
	cameraState.setDegree(cameraState.getWidth()/90);
	cameraState.setDegreeY(cameraState.getHeight()/90);
	this.mCamera = new Camera(0, 0, cameraState.getWidth(), cameraState.getHeight());
	EngineOptions engineOptions = new EngineOptions(true, ScreenOrientation.LANDSCAPE, new RatioResolutionPolicy(cameraState.getWidth(), cameraState.getHeight()), mCamera).setNeedsSound(true);;
	return new Engine(engineOptions);
}

public void onLoadResources()
{
	//loading font
	FontFactory.setAssetBasePath("other/");
	final ITexture fontTexture = new BitmapTextureAtlas(256, 256, TextureOptions.BILINEAR);
	Font mFont = FontFactory.createFromAsset(fontTexture, this.getBaseContext(), "sansareg.ttf", 48, true, Color.WHITE);
	this.getEngine().getFontManager().loadFont(mFont);
	
/*	SVGBitmapTextureAtlasTextureRegionFactory.setAssetBasePath("gfx/");
	try {
		this.mBuildableBitmapTextureAtlas.build(new BlackPawnTextureBuilder<IBitmapTextureAtlasSource, BitmapTextureAtlas>(1));
	} catch (final TextureAtlasSourcePackingException e) {
	Debug.e(e);
	}
	this.mEngine.getTextureManager().loadTexture(this.mBuildableBitmapTextureAtlas);*/
}

public Scene onLoadScene() {
	mEngine.registerUpdateHandler(new FPSLogger());
	//Creating Scene
	final Scene scene = new Scene();
	world = new World(1, cameraState.getWidth(),cameraState.getHeight(),this,3);
this.mEngine.registerUpdateHandler(new IUpdateHandler() {
@Override
	public void onUpdate(float pSecondsElapsed){
	
	world.updateWorld(cameraState.getDegree(),cameraState.getDegreeY(),cameraState.getWidth(),cameraState.getHeight(),touchX,touchY,scene);
	

}
@Override
public void reset() {}});
return scene;
}
@Override
public void onLoadComplete() {}
void loadTexture ()
{
}

@Override
public boolean onSceneTouchEvent(Scene pScene, TouchEvent pSceneTouchEvent) {
	// TODO Auto-generated method stub
	touchX=pSceneTouchEvent.getX();
	touchY=pSceneTouchEvent.getY();
	return false;
}
}