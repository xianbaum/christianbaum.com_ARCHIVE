package xian.baum.punchingoutcthulhu;

public enum FadeColor
{
BLACK,
GREY,
WHITE,
PURPLE,
BLUE
}