package xian.baum.punchingoutcthulhu;

import android.util.Log;
import android.view.KeyEvent;

class debug
{
boolean debugKeyboard(KeyEvent event, Player player, boolean debug, int DebugVarNo,int DebugVarNo2,int DebugVarNo3)
{
	int x = event.getKeyCode();
	int D=KeyEvent.KEYCODE_D;
	int GetAction = event.getAction();
	int ActionDown=KeyEvent.ACTION_DOWN;
	if(GetAction==ActionDown)
	{
	if(debug)
	{
		if(x==D&&debug)
		{
			Log.d("Punching","Debug:Disabled");
			debug=false;
			x=0;
		}
		if(debug)
		{
		if(x==21)
				DebugVarNo--;
		if(x==22)
			DebugVarNo++;
		if(x==52)
			DebugVarNo2--;
		if(x==31)
			DebugVarNo2++;
		if(x==30)
				DebugVarNo3--;
			if(x==42)
				DebugVarNo3++;
				switch(DebugVarNo)
		{
			case -1:{
				DebugVarNo=10;}
			break;
			case 0:
				Log.d("player.X","("+player.X+","+player.Y+","+player.Z+")");
				Log.d("player.X,Y,Z","UIO,JKL modifies this.");
				if(x==49)
					player.X++;
				if(x==37)
					player.Y++;
				if(x==43)
					player.Z++;
				if(x==38)
					player.X--;
				if(x==39)
					player.Y--;
				if(x==40)
					player.Z--;
			break;
			case 2:
				Log.d("Keystroke",""+event.getKeyCode()+" "+KeyEvent.KEYCODE_D);
				Log.d("Keystoke","NoAction");
			break;
			case 4:
/*				Log.d("enemy["+DebugVarNo2+"].location","("+enemy[DebugVarNo2].X+","+enemy[DebugVarNo2].Y+","+enemy[DebugVarNo2].Z+")");
				Log.d("enemy X,Y,Z","UIO,JKL modifies this.");
				if(x==49)
					enemy[DebugVarNo2].X++;
				if(x==37)
					enemy[DebugVarNo2].Y++;
				if(x==43)
					enemy[DebugVarNo2].Z++;
				if(x==38)
					enemy[DebugVarNo2].X--;
				if(x==39)
					enemy[DebugVarNo2].Y--;
				if(x==40)
					enemy[DebugVarNo2].Z--;
			break;
			case 3:
				Log.d("enemy["+DebugVarNo2+"].limb["+DebugVarNo3+"]X,Y:","("+enemy[DebugVarNo2].limb[DebugVarNo3].X+","+enemy[DebugVarNo2].limb[DebugVarNo3].Y+")");
				Log.d("player.X,Y,Z","UIO,JKL modifies this.");
				if(x==49)
					enemy[DebugVarNo2].limb[DebugVarNo3].X++;
				if(x==37)
					enemy[DebugVarNo2].limb[DebugVarNo3].Y++;
				if(x==38)
					enemy[DebugVarNo2].limb[DebugVarNo3].X--;
				if(x==39)
					enemy[DebugVarNo2].limb[DebugVarNo3].Y--;;*/
			break;
			case 5:
				
			break;
			case 11:{
				DebugVarNo=-1;
				}
			break;
			}}
			}
		if(x==D&&debug==false)
		{
			Log.d("Punching","Debug:Enabled");
			debug=true;
			Log.d("Punching","Press LEFT or RIGHT to cycle through menu.");
			Log.d("Punching","X or C - enemy number. B or N - limb number");
			Log.d("Punching","If you're not careful enemy number will crash");
//			Log.d(""+player.limb[0].X,""+player.limb[0].Y);
//			Log.d(""+player.limb[1].X,""+player.limb[1].Y);
		}
		}
		return false;
}
}