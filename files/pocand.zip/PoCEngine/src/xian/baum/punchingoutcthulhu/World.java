package xian.baum.punchingoutcthulhu;

import org.anddev.andengine.entity.scene.Scene;

import android.content.Context;

public class World
{
boolean flag[],
isPaused;
Room room;
Player player;
float time;
void setFlag(int flagNo)
{
	this.flag[flagNo]=!this.flag[flagNo];
}

void pauseGame()
{
	isPaused=true;
}

void unpauseGame()
{
	isPaused=false;
}

void updateTime()
{
	if(!isPaused)
	{
		time+=.02;
	}
}

void setText(String text)
{
	
}

void startGame(int worldType)
{
	//TODO do this
	time=0;
	
}

void enterRoom(int roomType,int  cameraWidth,int cameraHeight,Context context, int vidO)
{
	this.room = null;
	this.room = new Room(roomType, cameraWidth, cameraHeight, context, vidO);
}

void updateWorld(int degree, int degreeY, int cameraWidth, int cameraHeight, float touchX, float touchY, Scene scene)
{
	for(int x=0;x<=8;x++)
	{
		if(room.actor[x]==null)
			break;
		room.actor[x].actorUpdater(player.X,player.Y,player.Z,player.angle, player.isPunching, touchX, touchY, cameraWidth, cameraHeight, scene);
	}
	scene.sortChildren();
	room.updateRoom(degree, degreeY, cameraWidth, cameraHeight, touchX, touchY, scene);
}

World(int worldtype,int cameraWidth, int cameraHeight, Context context, int videoOptions)
{
	switch (worldtype) {
	case 1:
	{	
		room = new Room(2, cameraWidth, cameraHeight, context, videoOptions);
	}
	break;
	}
}


}
