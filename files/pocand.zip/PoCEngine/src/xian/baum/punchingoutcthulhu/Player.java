package xian.baum.punchingoutcthulhu;

import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.input.touch.TouchEvent;

import android.content.Context;

class Player extends Actor
{
Player(int type, int gX, int gY, int gZ, int videoOptions, int cameraWidth, int cameraHeight, Context context) {
		super(type, gX, gY, gZ, cameraWidth, cameraHeight, videoOptions, context);
		// TODO Auto-generated constructor stub and some other stuff????
	}

enum State {STOPPED,MOVING,PUNCHING,DEAD};

void initialize()
{
	//TODO 
}

void updatePlayer(int degree, int degreeY)
{
	checkAngle();
	limb[0].sprite.setPosition(((this.limb[0].getX()*degree)-(this.limb[0].sprite.getWidth()/2)),(this.limb[0].getY()*degreeY)-(this.limb[0].sprite.getHeight()/4));
	limb[1].sprite.setPosition(((this.limb[1].getX()*degree)-(this.limb[0].sprite.getWidth()/2)),(this.limb[1].getY()*degreeY)-(this.limb[1].sprite.getHeight()/4));
	limb[0].sprite.setScale(this.limb[0].getGrowth());
	limb[1].sprite.setScale(this.limb[1].getGrowth());
}

//code copied and pasted from my touch class. It worked there but might not work here. Not testing this right now though

float InitialX,//touch variables
InitialY,
CurrentX,
CurrentY,
LastX,
LastY,
touchTimer,
touchX1,
touchY1,
touchY2,
touchX2;
boolean isTouching;
public boolean onSceneTouchEvent(final Scene pScene, final TouchEvent pSceneTouchEvent, float degree) {
	if(pSceneTouchEvent.isActionDown()){
		if(!isTouching)
			{InitialX = pSceneTouchEvent.getX();
			InitialY = pSceneTouchEvent.getY();}
		isTouching=true;}
	else if(pSceneTouchEvent.isActionMove()){
		CurrentX=(InitialX-pSceneTouchEvent.getX())/degree;
		CurrentY=(InitialY-pSceneTouchEvent.getY())/degree;
		if(CurrentX-LastX<degree*2&&CurrentX-LastX>-degree*2)
		{		
			this.angle-=LastX-CurrentX;
		}
		LastX=CurrentX;}
	else if(pSceneTouchEvent.isActionUp())
	{
		isTouching=false;
		if(touchTimer<.25f)
		{	this.isPunching=true;
			this.instruction=1;
			if(this.limb[1].getInstruction()==1&&this.limb[0].getInstruction()==1&&this.isRightHand||
					this.limb[1].getInstruction()==2&&this.limb[0].getInstruction()==1&&this.isRightHand||
					this.limb[1].getInstruction()==1&&this.limb[0].getInstruction()==2&&this.isRightHand||
					this.limb[1].getInstruction()==2&&this.limb[0].getInstruction()==2&&this.isRightHand)
			{
				this.limb[1].setInstruction(1);
				this.isRightHand=false;
				touchX2=InitialX;
				touchY2=InitialY;
			}
			else if(this.limb[1].getInstruction()==1&this.limb[0].getInstruction()==1&&!this.isRightHand||
					this.limb[1].getInstruction()==2&this.limb[0].getInstruction()==1&&!this.isRightHand||
					this.limb[1].getInstruction()==1&this.limb[0].getInstruction()==2&&!this.isRightHand||
					this.limb[1].getInstruction()==2&this.limb[0].getInstruction()==2&&!this.isRightHand)
			{
				this.limb[0].setInstruction(1);
				this.isRightHand=true;
				touchX1=InitialX;
				touchY1=InitialY;
			}
			if(this.isRightHand)
			{
				this.limb[0].setInstruction(1);
				this.limb[0].setIsAtTarget(true);
				this.limb[0].setGrowth(1);
				this.isRightHand=false;
				touchX2=InitialX;
				touchY2=InitialY;
			}
			else if(!this.isRightHand)
			{
				this.limb[1].setGrowth(1);
				this.limb[1].setInstruction(1);
				this.limb[1].setIsAtTarget(true);
				this.isRightHand=true;
				touchX1=InitialX;
				touchY1=InitialY;
			}
		}
		touchTimer=0;
		LastX=0;
		LastY=0;
		InitialX=0;
		InitialY=0;
		CurrentY=0;
		return false;}
		return true;
	}

}
