--NPC class ------------------------------------------------------------------------------------------------
--AI TYPES
--1: Wander, attack on sight
--2: Rotate, attack on sight, go back to spot
--3: 

NPC = {}
NPC.__index = NPC

function NPC.create( number, x, y, ai_type, messageno, damage, mapno )
   local npc = {}
   
   --image is optional
   if number then
      --image
      npc.image = love.graphics.newImage("assets/sprites/npc"..number..".png")
      npc.image:setFilter( "nearest" )
   end

   npc.health = 100

   --food and map is for player
   npc.food = 100
   npc.mapno = mapno
   npc.mapkey = 0
   
   --anim
   npc.grid = anim8.newGrid(16, 16, 64, 128)
   npc.anim = anim8.newAnimation(npc.grid(1, '1-1'), 0.25)
   npc.flash = false
   
   --pos
   npc.x = x*16
   npc.y = y*16
   npc.tx = npc.x
   npc.ty = npc.y
   
   npc.ai = ai_type
   npc.number = number
   npc.speed = 24
   
   --state and Direction state
   npc.state = "standing" -- ooing, walking, standing, attacking, returning, going, investigating, crawling
   npc.ydir, npc.lastydir, npc.tydir  = "down", "down", "down"
   npc.dir, npc.lastdir, npc.tdir = "none", "none", "none"
   npc.ccw = false
   
   --Action counter is for changing AI state. Actually, it's a timer instead of a counter but eh
   npc.action_counter=10

   --Cooldown after attack? (so it doesn't immediately attack)
   npc.cooldown = false

   --Usually 25
   npc.damage = damage or 25
   npc.messageno = messageno or nil

   --If NPC is killed, check this flag
   npc.flag = flag or nil

   --Waypoints are just where they walk to
   npc.cw = 0 --Current waypoint
   npc.wps = {}

   npc.iwp = {} --Investigate waypoint

   npc.target = 1000

   if npc.number == 17 then
      npc.grid = anim8.newGrid(16, 16, 128, 128)
   end
   
   if npc.ai == 2 then
      npc.wps[0] = {}
      npc.wps[0].x = npc.x
      npc.wps[0].y = npc.y
   end

   return setmetatable(npc, NPC )
end

--For use by player
function NPC:interact( npcs, players, myindex )

   --Check if an NPC is near
   for _, npc in ipairs( npcs ) do --Different hitboxes for different dirs
      if self.ydir == "up" and
	 isColliding( self.x,self.y-16,16,24, npc.x+4, npc.  y+12, 8, 4 ) or
	 self.ydir == "down" and
	 isColliding( self.x, self.y+16,16,16, npc.x+4, npc.y+12, 8, 4 ) or
	 self.dir == "left" and
	 isColliding(self.x-16, self.y, 16,24, npc.x+4, npc.y+12, 8, 4 ) or
	 self.dir == "right" and
      isColliding(self.x, self.y, 16,24, npc.x+4, npc.y+12, 8, 4 ) then

	 --If the NPC has a messsage, change the gamestate and display it TODO: change how this works?
	 if npc.messageno then
	    return Message.create( npc.messageno )
	 end
      end
   end

   --If that was unsuccessful, see if a player is in talking distance or following
   for i, player in pairs(players) do
      if player.state == "following" and i ~= self.myindex and player.mapno == self.mapno or
      player.state == "following2" and i~= self.myindex and player.mapno == self.mapno then
	 return Message.create( 0,i,true )
      elseif player.state ~= "following" and player.mapno == self.mapno and i~= self.myindex then
	 if self.ydir == "up" and 
	    isColliding( self.x,self.y-16,16,24, player.x+4, player.  y+12, 8, 4 ) or
	    self.ydir == "down" and
	    isColliding( self.x, self.y+16,16,16, player.x+4, player.y+12, 8, 4 ) or
	    self.dir == "left" and
	    isColliding(self.x-16, self.y, 16,24, player.x+4, player.y+12, 8, 4 ) or
	    self.dir == "right" and
	 isColliding(self.x+16, self.y, 16,24, player.x+4, player.y+12, 8, 4 ) then
	    return Message.create( 1,i, true )
	 end
      end
   end

   return Message.create( 2 )
   
end

--This is only for players
function NPC:updatePlayer( dt, map, player, isCP) -- "up" "down" "left" "right" 
   self.action_counter = self.action_counter + dt

   --TODO: REMOVE THIS
   if not counter then
      counter = 0
   end
   if love.keyboard.isDown( "j" ) and counter > 0.1 then
      self:rotate()
      counter = 0
   end
   counter =counter+ dt
   
   --for hitjump
   local jumpx = self.x
   local jumpy = self.y
   
   --Running is based on how much food you have. TODO: Keep this?
   if self.state ~= "cooldown" then --Check if an attacking NPC is colliding with you
      for _, npc in ipairs(map.n) do
	 if self:isAtWaypoint( npc.x, npc.y, true ) and
	    npc.state == "attacking" and self.cooldown == false and
	 self.state ~= "following" and self.state ~= "following2" then
	    self.state = "cooldown"
	    self.action_counter = 0
	    self.health = self.health - npc.damage
	 end
      end
      --If action timer is less than 1/10 of a second, then jump. 
   elseif self.action_counter < 0.25 then
      if self.ydir == "up" then
	 jumpy = jumpy - 100
      elseif self.ydir == "down" then
	 jumpy = jumpy + 100
      end
      if self.dir == "left" then
	 jumpx = jumpx - 100
      elseif self.dir == "right" then
	 jumpx = jumpx + 100
      end
   elseif self.action_counter > 1 then
      self.state = "standing"
   end
   
   if self.state == "rotating" then
      if self.action_counter > 0.05 then
	 self:rotate(self.ccw)
	 self.action_counter = 0
      end
      if self.tdir == self.dir and self.tydir == self.ydir then
	 self.state = "standing"
      end
   end

   --If the jump location is different than the actual location, move and check collision
   if jumpy~= self.y or jumpx ~= self.x then
      self.speed = 72
      jumpx, jumpy = self:goto( dt, jumpx, jumpy, true )
      self:checkCollision( jumpx, jumpy, map.c)
      self.speed = 24
   end

   self.tx = self.x
   self.ty = self.y

   --only control if is the current player
   if isCP then
      if love.keyboard.isDown( runkey ) and self.food > 75 then
	 self.speed = 72
      elseif love.keyboard.isDown( runkey ) and self.food > 40 then
	 self.speed = 48
      else
	 self.speed = 24
      end
      
      --Get key input
      if love.keyboard.isDown( rightkey ) then
	 self.tx = self.tx + 100
      end
      if love.keyboard.isDown( leftkey ) then
	 self.tx = self.tx - 100
      end
      if love.keyboard.isDown( upkey ) then
	 self.ty = self.ty - 100
      end
      if love.keyboard.isDown( downkey ) then
	 self.ty = self.ty + 100
      end
   end
   
   --If the temp location is different than the actual location, check collision and then check if at a door
   if self.state ~= "rotating" and self.state ~= "cooldown" then
      if self.ty~= self.y or self.tx ~= self.x then

	 --Do movement then check collisoin
	 self.state = "walking"
	 self.tx, self.ty = self:goto( dt, self.tx, self.ty, true )
	 self:checkCollision( self.tx, self.ty, map.c)

	 --then check door colision
	 for _, door in ipairs(map.d) do
	    if self:isAtWaypoint( door.x, door.y ) then
	       return door.mapno, door.tox, door.toy
	    end
	 end
      elseif self.state == "following" and not isColliding( self.x, self.y, 16, 16, player[self.target].x, player[self.target].y, 16, 16 ) or self.state == "following2" and not isColliding( self.x, self.y, 16, 16, player[self.target].x, player[self.target].y, 16, 16 ) then
	 self.state = "following"
	 self.speed = player[ self.target ].speed

	 --go, check collision
	 tempx, tempy = self:goto( dt, player[ self.target ].x, player[self.target].y )
	 self:checkCollision( self.tx, self.ty, map.c)

	 --Is the follower stuck?
	 if not isColliding( self.x -16, self.y -16, 48, 48, player[self.target].x, player[self.target].y, 16, 16 ) then
	    self.x,self.y = player[ self.target].x, player[ self.target].y
	 end
      elseif self.state == "following" or self.state == "following2" then
	 self.state = "following2"
      else
	 self.state = "standing"
      end
   end
   if love.keyboard.isDown( "t" ) then
      self.state = "doing"
   end
   if love.keyboard.isDown( "y" )then
      self.state = "crawling"
   end
end

--Returns true if it's at the waypoint, false if not.
function NPC:isAtWaypoint( x, y, truu )

   --truu is whether to check a NPC sized hitbox or if not truu, then check use a door-sized hitbox
   if truu then
      if isColliding( self.x+4, self.y+12, 8, 4,
		      x+4, y+12, 8, 4 ) then
	 return true
      end
      return false
   elseif isColliding( self.x+4, self.y+12, 8, 4, x, y, 16, 16 ) then
      return true
   end
   return false
end

--Sets an NPC to a certain spot
function NPC:set( x, y)
   self.x = x
   self.y = y
end

function NPC:draw( mapno )
   if self.mapno == mapno then
      if self.cooldown == true then
	 self.flash = not self.flash
      else
	 self.flash = false
      end
      if not self.flash and self.image then
	 self.anim:draw(self.image, round(self.x*2)/2,round(self.y*2)/2)
      end
   end
end

--Only used by current player
function NPC:drawHud(drawX, drawY)
   if self.health ~= 100 then
      love.graphics.setColor(255,255,255)
      love.graphics.rectangle("line", round((7-drawX)*2)/2,round((7-drawY)*2)/2,22,4)
      love.graphics.setColor(255,0,0)
      love.graphics.rectangle( "fill", round((8-drawX)*2)/2,round((8-drawY)*2)/2,self.health/5,2)
      love.graphics.setColor(255,255,255)
   end
end

--This function updates palyer AI
function NPC:update( dt, map, player, playerNum )
   --Update action counter
   self.action_counter = self.action_counter + dt

   --Wander AI
   if self.ai == 1 then

      --Change state or dir at action counter limit
      if self.action_counter > 5 then
	 if self.state == "attacking" then
	    self.action_counter = 2
	    self.cooldown = true
	 else
 	    self.cooldown = false
	 end
	 self:doAction()
	 self.action_counter = 0
      end

      if self.state == "walking" then
	 self:walk( dt, map.c )
      end

      --Rotate AI
   elseif self.ai == 2 then

      --Change state or dir at action counter limit
      if self.action_counter > 2.5 then
	 if self.state == "attacking" then
	    self.state = "returning"
	    self.cooldown = true
	 end
	 
	 if self.state == "standing" then
	    self:rotate()
	 end
	 self.action_counter = 0
      end

      if self.state == "returning" then
	 self.x, self.y = self:goto( dt, self.wps[0].x, self.wps[0].y )
	 if self:isAtWaypoint( self.wps[0].x, self.wps[0].y ) then
	    self.action_counter = 100
	    self.state = "standing"
	    self.cooldown = false
	 end
      end

   --Waypointing/patrolling AI
   elseif self.ai == 3 then
      --If it's at the waypoint, add 1 to current wayopint
      if isAtWaypoint( self.wps[ self.cw ].x, self.wps[ self.cw ].y ) then
	 self.cw = self.cw + 1

	 --If the current waypoint does not exist, put it to 0
	 if not self.wps[ self.cw ] then
	    self.cw = 0
	 end
      end
      self.x, self.y = self:goto( dt, self.wps[ self.cw].x, self.wps[ self.cw].y )
   end

   --Aggresive AI
   if self.ai == 1 or self.ai == 2 then
      self:checkAttack( player )
      if self.state == "attacking" then
	 self:attack( dt, player, map.c )
      end
   end
   
end

--Checks if it's attacking, then attacks
function NPC:checkAttack( player )
   if not self.cooldown and self.state ~= "attacking" then
      for _, p in pairs( player ) do
	 if p.mapno == self.mapno then
	    --TODO: 45 degree FOV
	    if self.ydir == "up" and
	       isColliding( self.x-24,self.y-48,64,48, p.x+4, p.y+12, 8, 4 ) or
	       self.ydir == "down" and
	       isColliding( self.x-24, self.y+16,64,48, p.x+4, p.y+12, 8, 4 ) or
	       self.dir == "left" and
	       isColliding(self.x-48, self.y-24, 48, 64, p.x+4, p.y+12, 8, 4 ) or
	       self.dir == "right" and
	       isColliding(self.x+16, self.y-24, 48, 64, p.x+4, p.y+12, 8, 4 ) or
	       isColliding( self.x-32, self.y-32, 88, 88, p.x+4, p.y+12, 5, 4 )
	       and p.speed > 24 or
	    isColliding( self.x-8, self.y-8, 32, 32, p.x+4, p.y+12, 5, 4 )then
	       self.state = "attacking"
	       self.action_counter = 0
	       self.target = _
	       return 0
	    end
	 end
      end
   end
end

--rotates 45 degrees
function NPC:rotate(ccw) --counterclockwise
   if self.ydir == "up" and self.dir == "left" and not ccw or
   self.ydir == "up" and self.dir == "right" and ccw then
      self.ydir = "up"
      self.dir = "none"
   elseif self.ydir == "up" and self.dir == "none" and not ccw or
   self.ydir == "none" and self.dir == "right" and ccw then
      self.ydir = "up"
      self.dir = "right"
   elseif self.ydir == "up" and self.dir == "right" and not ccw  or
      self.ydir == "down" and self.dir == "right" and ccw then
	 self.ydir = "none"
	 self.dir = "right"
   elseif self.ydir == "none" and self.dir == "right" and not ccw or
   self.ydir == "down" and self.dir == "none" and ccw then
      self.ydir = "down"
      self.dir = "right"
   elseif self.ydir == "down" and self.dir == "right" and not ccw or
   self.ydir == "down" and self.dir == "left" and ccw then
      self.ydir = "down"
      self.dir = "none"
   elseif self.ydir == "down" and self.dir == "none" and not ccw or
   self.ydir == "none" and self.dir == "left" and ccw then
      self.ydir = "down"
      self.dir = "left"
   elseif self.ydir == "down" and self.dir == "left" and not ccw or
   self.ydir == "up" and self.dir == "left" and ccw then
      self.ydir = "none"
      self.dir = "left"
   elseif self.ydir == "none" and self.dir == "left" and not ccw or
   self.ydir == "up" and self.dir == "none" and ccw then
      self.ydir = "up"
      self.dir = "left"
   end
end

--Note that collision is a factor.
function NPC:attack( dt, player, collision )
   for _, p in pairs( player ) do
      if self.target == _ then
	 local tempx = self.x
	 local tempy = self.y

	 self.speed = 48
	 tempx, tempy = self:goto( dt, p.x, p.y )
	 self.speed = 24
	 self:checkCollision( tempx, tempy, collision )
	 break
      end
   end
end

--Truu is for player movement basically
function NPC:goto( dt, x,y, truu )
   local tempx = self.x
   local tempy = self.y

   local tempxdir = "none"
   local tempydir = "none"
   
   --Left/right movement
   if not isColliding( self.x+4, tempy+12, 8, 4, x+6, 0, 4, 100000 ) then
      if x < tempx then
	 tempx = tempx - self.speed*dt
	 tempxdir = "left"
      elseif x > tempx then
	 tempx = tempx + self.speed*dt
	 tempxdir = "right"
      end
   end

   --Up/down movement
   if not isColliding( self.x+4, tempy+12, 8, 4, 0, y+13, 100000, 3 ) then
      if y > tempy then
	 tempy = tempy +self.speed*dt
	 if math.abs(tempy-y) > math.abs(tempx-x) or truu then
	    tempydir = "down"
	 end
      elseif y < tempy then
	 tempy = tempy - self.speed*dt
	 if math.abs(tempy-y) > math.abs(tempx-x) or truu then
	    tempydir = "up"
	 end
      end
   end
   if tempydir ~= "none" or tempxdir ~= "none" then
      self.tdir = tempxdir
      self.tydir = tempydir
   end
   if self.tdir ~= self.dir or self.tydir ~= self.ydir then
      self:calculateCCW()
      self.state = "rotating"
      self.action_counter = 1
   end
   return tempx, tempy
end

function NPC:setLastDir()
   self.lastdir = self.dir
   self.lastydir = self.ydir
end

function NPC:walk( dt, collision )
   local tempx = self.x
   local tempy = self.y

   --Update movement
   if self.dir == "left" then
      tempx = tempx - 24*dt
   elseif self.dir == "right" then
      tempx = tempx + 24*dt
   end
   if self.ydir == "up" then
      tempy = tempy - 24*dt
   elseif self.ydir == "down" then
      tempy = tempy + 24*dt
   end
   self:checkCollision( tempx, tempy, collision )
end

function NPC:doAction()
   local number = math.random( 3 )
   if number == 1 then
      self.state = "walking"
   elseif number == 2 then
      self.state = "standing"
   else
      self.state = "barking"
   end
   local number = math.random( 3 )
   if number == 1 then
      self.ydir = "up"
   elseif number == 2 then
      self.ydir = "down"
   else
      self.ydir = "none"
   end
   local number = math.random( 3 )
   if number == 1 then
      self.dir = "left"
   elseif number == 2 then
      self.dir = "right"
   else
      self.dir = "none"
   end
   --lol
   if self.dir == "none" and self.ydir == "none" then
      self.ydir = "down"
   end
end

function NPC:checkCollision( tempx, tempy, collision )
   local collidingDir = { false, false, false, false }
   for _, point in ipairs(collision) do
      collidingDir = self:checkSquareCollision(tempx, tempy, point.x, point.y)
      if point.t then
	 if point.t == 1 then -- Square
	    collidingDir = checkSquareCollision( tempx, tempy, point.x, point.y )
	 elseif point.t == 2 then -- Triangle /|
	    collidingDir = checkSquareCollision(tempx, tempy, point.x, point.y)
	    if collidingDir[0] == true or collidingDir[1] == true then
	       collidingDir = checkTriangleCollision(collidingDir, tempx, tempy, point.x, point.y, true)
	    end
	 elseif point.t == 3 then -- Triangle |/
	    collidingDir = checkSquareCollision(tempx, tempy, point.x, point.y)
	 elseif point.t == 4 then -- Shadow Square
	    collidingDir = checkSquareCollision( tempx, tempy, point.x, point.y )
	 elseif point.t == 5 then -- Shadow triangle |/
	 elseif point.t == 6 then -- Crawlspace Square
	 elseif point.t == 7 then --Crawlspace tirangle |/
	 elseif point.t == 8 then --Crawlspace triangle /|
	 end
      else

      end
      
   end

   --So the NPC doesn't get stuck if colliding, and instead slides
   if collidingDir[1] == false then
      self.y = tempy
   end
   if collidingDir[2] == false then
      self.x = tempx
   end
end

function NPC:checkSquareCollision( tempx, tempy, pointx, pointy )
   local collidingx = false
   local collidingy = false
   if isColliding( self.x+4, tempy+12, 8, 4,
		   pointx, pointy, 16, 16 ) then
      collidingx=true
   end
   if isColliding( tempx+4, self.y+12, 8, 4,
		   pointx, pointy, 16, 16 ) then
      collidingy=true
   end
   return {collidingx, collidingy, false, false}
end
      
function NPC:checkTriangleCollision( tempx, tempy, pointx, pointy )
   
end

function NPC:addWaypoint( x, y)
   local w = {}
   w.x = x
   w.y = y
   table.insert( w, self.wps )
end

function NPC:setMapNo( mapno)
   self.mapno = mapno
end

function NPC:updateAnim( dt )
   --Standing frame
   local frames = "1-1"

   --Walking frame
   if self.state == "walking" or self.state == "attacking" or self.state == "returning" or self.state == "following" then
      frames = "2-3"

      --crouching oor player, idk if it's for other sprites
   elseif self.state == "doing" then
      frames = "4-4"
   elseif self.state == "crawling" then
      frames = "5-6"
   end
   --The row of the spritesheet depends on the direction
   if self.lastdir ~= self.dir or self.ydir ~= self.lastydir or self.laststate ~= self.state then
      if self.ydir == "up" and self.dir == "none" then	
	 self.anim = anim8.newAnimation(self.grid(frames,4),0.25)
      elseif self.ydir == "down" and self.dir == "none" then
	 self.anim = anim8.newAnimation(self.grid(frames,1), 0.25)
      elseif self.ydir == "none" and self.dir == "left" then
	 self.anim = anim8.newAnimation(self.grid(frames,3), 0.25)
      elseif self.ydir == "none" and self.dir == "right" then
	 self.anim = anim8.newAnimation(self.grid(frames,2), 0.25)
      elseif self.ydir == "down" and self.dir == "left" then
	 self.anim = anim8.newAnimation(self.grid(frames,5), 0.25)
      elseif self.ydir == "down" and self.dir == "right" then
	 self.anim = anim8.newAnimation(self.grid(frames,6), 0.25)
      elseif self.ydir == "up" and self.dir == "left" then
	 self.anim = anim8.newAnimation(self.grid(frames,7), 0.25)
      elseif self.ydir == "up" and self.dir == "right" then
	 self.anim = anim8.newAnimation(self.grid(frames,8), 0.25)
      end
   end
   self.lastdir = self.dir
   self.lastydir = self.ydir
   self.laststate = self.state
   self.anim:update( dt )
end

function NPC:setMapKey( key )
   self.mapkey = key
end

function NPC:setFromSave( x, y, state, action_counter, cooldown, dir, health, food, map )
   self.x = x
   self.y = y
   
   --We don't have to set these if it's a player.
   if state then self.state = state end
   if action_coutner then self.action_counter = action_counter end
   if cooldown then self.cooldown = cooldown end
   if dir then self.dir = dir end

   --Some NPCs don't use health so it doesn't matter if we have this value
   if health then self.health = health end
   
   --We dont' have to set these if it's an npc
   if food then self.food = food end
   if map then self.mapno = map end
end

function NPC:setState( state )
   self.state = state
end

function NPC:setTarget( target )
   self.target = target
end

function NPC:calculateCCW()
   if self.ydir == "up" and self.dir == "none" then
      if self.tdir == "left" then self.ccw = true
      else self.ccw = false end
   elseif self.ydir == "up" and self.dir == "left" then
      if self.tdir == "left" or self.ydir == "down" then self.ccw = true
      else self.ccw = false end
   elseif self.ydir == "none" and self.dir == "left" then 
      if self.tydir == "down" then self.ccw = true
      else self.ccw = false end
   elseif self.ydir == "down" and self.dir == "left" then--accidentally reversed some lol
      if self.tdir == "down" or self.tdir == "left" then self.ccw = false
      else self.ccw = true end
   elseif self.ydir == "down" and self.dir == "none" then
      if self.tdir == "right" then self.ccw = true
      else self.ccw = false end
   elseif self.ydir == "down" and self.dir == "right" then
      if self.tdir == "right" or self.tdir == "up" then self.ccw = true
      else self.ccw = false end
   elseif self.ydir == "none" and self.dir == "right" then
      if self.tydir == "up" then self.ccw = true
      else self.ccw = false end
   else
      if self.tydir == "up" or self.tdir == "left" then self.ccw = true
      else self.ccw = false end
   end
end
