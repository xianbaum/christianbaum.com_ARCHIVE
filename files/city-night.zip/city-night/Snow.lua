--meow

Snow = {}
Snow.__index = Snow

function Snow.create( drawX, drawY )
   drawX = drawX or 0
   drawY = drawY or 0
   
   local snow = {}
   snow.y= math.random(windowHeight/4)+drawY
   snow.x= math.random(200)+drawX
   snow.xvelocity = math.random(-25,25)
   snow.yvelocity = math.random(50)

   return setmetatable(snow, Snow)
end

function Snow:update( dt, drawX, drawY, windowWidth, windowHeight )
   self.x = self.x + self.xvelocity/10*dt
   self.y = self.y + self.yvelocity/1*dt
   local function createNewSnow( x,y)
      self.y = y
      self.x= x
      self.xvelocity = math.random(-25,25)
      self.yvelocity = math.random(50)
   end

   --If the snow is off screen, make another one to fill its place.
   if self.y>151+drawY then
      createNewSnow( math.random(0,windowWidth/4)+drawX, drawY)
   elseif self.y < drawY-1 then
      createNewSnow( math.random(0,windowWidth/4)+drawX, drawY+149)
   elseif self.x>201+drawX then
      createNewSnow(drawX, drawY+math.random(0,windowHeight/4))
   elseif self.x<drawX-1 then
      createNewSnow(drawX+200, drawY+math.random(0,windowHeight/4))
   end
end

--Draws the snow. Changes the color to the snow color, draws it, then changes it back.
function Snow:draw(r,g,b)
   r,g,b = r or 255, g or 255, b or 255
   love.graphics.setColor(119,133,133,255)
   love.graphics.point( round(self.x)+.5, round(self.y)+.5 )
   love.graphics.setColor(r,g,b)
end

