--TODO: Refactor.
--A player Should be an NPC
--Change how NPCs store message box data.
--TODO: multiple
--TODO: Save NPC health, player AC, player cooldown

sti = require 'sti'
anim8 = require 'anim8'
require 'TEsound'
require 'Snow'
require 'functions'
require 'NPC'
require 'Message'
require 'MapInfo'
require 'Scene'
require 'monocle'
Monocle.new({ true, false, {255,255,255}, '`', {'main.lua', 'Message.lua', 'MapInfo.lua', 'NPC.lua', 'functions.lua' }})

-- Love2D Functions-----------------------------------------------------------------------------------------

function love.load()

   --window stuffcd
   icon = love.image.newImageData("assets/icon.png")
   love.window.setIcon( icon )
   love.window.setTitle( "City Night" )

   
   debugvar = false
   
   --Setting identity
   love.filesystem.setIdentity("RobinTheSuperhero")

   --Resetting file stuff to default before loading
   resetKeys()
   resetVolume()

   --Loading file stuff (starting with keybinds)
   local file = love.filesystem.load( "keys.lua")

   if not file then
      applyKeys()
   else
      file()
   end

   --Next, options
   file = love.filesystem.load( "options.lua" )
   if not file then
      applyOptions()
   else
      file()
     TEsound.volume("meow", menuvolume/100 )
     TEsound.volume("sfx", sfxvolume/100)
     TEsound.volume("music", musicvolume/100)
   end

   --Process options
   if startInFullscreen then
      love.window.setMode(800,600, {resizable = false, fullscreen = true, vsync = true } )
   end

   --Global graphics stuff stuff
   windowWidth = love.graphics.getWidth()
   windowHeight = love.graphics.getHeight()
   love.graphics.setPointSize(4)
   love.graphics.setPointStyle( "rough" )
   
   --Global assets (Loading them)
   cursor = love.graphics.newImage("assets/sprites/cursor.png")
   doot = love.sound.newSoundData("assets/audio/doot.wav")
   font = love.graphics.newImageFont("assets/sprites/font.png", " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ~abcdefghijklmnopqrstuvwxyz")
   title = love.graphics.newImage("assets/sprites/title.png")
   textbox = love.graphics.newImage("assets/sprites/textbox.png")
   dialogbox = love.graphics.newImage("assets/sprites/dialogbox.png")

   --Asset options
   cursor:setFilter("nearest")
   font:setFilter("nearest") -- I call setFilter immediately after each asset call.
   love.graphics.setFont(font)
   title:setFilter("nearest")
   textbox:setFilter("nearest")
   dialogbox:setFilter("nearest")
   
   gamestate = "menu" --Starts the game in this state when it loads up
   submenu = "main"--Starts in the main menu
   cursorPos = 0 --Starts with the cursor position at 0 or "Start game"

   errorx = "" --An error message. No error right now so it's initalized blank

   ttimer = 0 --ttimer is a global timer. t stands for total i guess
end

function love.textinput( text )
   Monocle.textinput( text )
end

-- Love.Keypressed
function love.keypressed(key)
   Monocle.keypressed(key)
   
   --If you selected to change a key in the controls menu, then change whatever keybind to the pressed key
   if gamestate == "changekey" and submenu == "controls" then

      if cursorPos == 0 then
	 upkey = key
      elseif cursorPos == 1 then
	 downkey = key
      elseif cursorPos == 2 then
	 leftkey = key
      elseif cursorPos == 3 then
	 rightkey = key
      elseif cursorPos == 4 then
	 runkey = key
      elseif cursorPos == 5 then
	 interactkey = key
      elseif cursorPos == 6 then
	 actionkey = key
      elseif cursorPos == 7 then
	 switchkey = key
      elseif cursorPos == 8 then
	 acceptkey = key
      elseif cursorPos == 9 then
	 pausekey = key
      elseif cursorPos == 10 then
	 menukey = key
      end

      --Change gamestate back to the menu after changing key
      gamestate = "menu"

   --If you selected to change audio in the audio menu then change the volume of selected audio
   elseif gamestate == "changekey" and submenu == "audio" then
      if key == leftkey then
	 if cursorPos == 0 then
	    menuvolume = menuvolume - 1
	 elseif cursorPos == 1 then
	    musicvolume = musicvolume - 1
	 elseif cursorPos == 2 then
	    sfxvolume = sfxvolume - 1
	 end
      elseif key == rightkey then
	 if cursorPos == 0 then
	    menuvolume = menuvolume + 1
	 elseif cursorPos == 1 then
	    musicvolume = musicvolume + 1
	 elseif cursorPos == 2 then
	    sfxvolume = sfxvolume + 1
	 end
      elseif key == upkey then
	 if cursorPos == 0 then
	    menuvolume = menuvolume - 10
	 elseif cursorPos == 1 then
	    musicvolume = musicvolume - 10
	 elseif cursorPos == 2 then
	    sfxvolume = sfxvolume - 10
	 end
      elseif key == downkey then
	 if cursorPos == 0 then
	    menuvolume = menuvolume + 10
	 elseif cursorPos == 1 then
	    musicvolume = musicvolume + 10
	 elseif cursorPos == 2 then
	    sfxvolume = sfxvolume + 10
	 end
      elseif key == acceptkey or key == menukey then
	 gamestate = "menu"
      end

      --The volumes should be in between 0 and 100.
      if sfxvolume < 0 then sfxvolume = 0 elseif sfxvolume > 100 then sfxvolume = 100 end
      if musicvolume < 0 then musicvolume = 0 elseif musicvolume > 100 then musicvolume = 100 end
      if menuvolume < 0 then menuvolume = 0 elseif menuvolume > 100 then menuvolume = 100 end
      
      --Set the changed audio
      TEsound.volume("meow", menuvolume/100 )
      TEsound.volume("sfx", sfxvolume/100)
      TEsound.volume("music", musicvolume/100)

   elseif gamestate == "menu" then

      if key == menukey then 
	 if submenu == "main" then --If you're in the main menu and press the menu key (esc), quit game
	    love.event.quit()
	 elseif submenu == "pausemenu" then --play game if in pause menu
	    gamestate = "play"
	    TEsound.resume("music")
	    cursorPos = 0
	 elseif submenu ~= "audio" and submenu ~= "controls" then -- Go back to previous menu
	    submenu = prevmenu
	 else --If in either of these menus, go back to the options menu
	    submenu = "options"
	 end
	 
      elseif key == downkey then --Moves cursor down if downkey is pressed
	 cursorPos = cursorPos + 1
	 TEsound.play(doot, "meow")
	 
      elseif key == upkey then --Moves cursor down
	 cursorPos = cursorPos - 1
	 TEsound.play(doot, "meow")
	 
      elseif key == acceptkey then --Does whatever action the menu item is

	 if submenu == "main" then --Main menu, is the menu that the game goes to on startup

	    if cursorPos == 0 then --"Start game"
	       startNewGame()

	    elseif cursorPos == 1 then --"Load game"
	       prevmenu = "main"
	       submenu = "loadmenu"
 	       cursorPos = 0

	    elseif cursorPos == 2 then --"Options"
	       prevmenu = "main"
	       submenu = "options"
	       cursorPos = 0

	    elseif cursorPos == 3 then --"Quit"
	       love.event.quit()
	    end
	    
	 elseif submenu == "loadmenu" then --"Load:"

	    if cursorPos == 10 then --"Back"
	       submenu = prevmenu

	    else --Loads from whatever slot is selected
	       if not love.filesystem.exists( "save"..cursorPos..".lua" ) then
		  TEsound.play("assets/audio/meow.wav", "meow")
	       else
		  loadGame( cursorPos )
	       end
	    end
	    
	 elseif submenu == "savemenu" then --"Save:"

	    if cursorPos == 10 then --"Back"
	       submenu = prevmenu

	    else --Savs to whatever slot is selected
	       saveGame( cursorPos )
	       TEsound.play("assets/audio/meow.wav", "meow")
	    end
	    
	 elseif submenu == "pausemenu" then --"Pause"

	    if cursorPos == 0 then --"Resume game"
	       gamestate = "play"
	       TEsound.resume("music")
	       
	    elseif cursorPos == 1 then--"Save game"
	       submenu = "savemenu"
	       prevmenu = "pausemenu"
	       cursorPos = 0
	       
	    elseif cursorPos == 2 then--"Load game"
	       submenu = "loadmenu"
	       prevmenu = "pausemenu"
	       cursorPos = 0
	       
	    elseif cursorPos == 3 then --"Options"
	       prevmenu = "pausemenu"
	       submenu = "options"
	       cursorPos = 0
	       
	    elseif cursorPos == 4 then --"Exit to main menu"

	       if unsaved then-- If you did not save, ask.
		  submenu = "reallyexit"
		  prevmenu = "pausemenu"
		  cursorPos = 0
		  
	       else --If you saved, do not ask
		  submenu = "main"
		  cursorPos = 0
	       end
	       
	    elseif cursorPos == 5 then --"Exit game"
	       
	       if unsaved then -- If you did not save, then ask
		  submenu = "reallyquit"
		  prevmenu = "pausemenu"
		  cursorPos = 0
		  
	       else --If you saved do not ask
		  love.event.quit()
	       end
	    end
	    
	 elseif submenu == "reallyexit" then --"Really exit? Unsaved data will be lost."

	    if cursorPos == 0 then --"Yes"
	       submenu = "main"
	       cursorPos = 0
	       prevmenu = "main"
	       
	    else --"No"
	       submenu = "pausemenu"
	       cursorPos = 0
	    end
	    
	 elseif submenu == "reallyquit" then --"Really quit? Unsaved data will be lost."

	    if cursorPos == 0 then --"Yes"
	       love.event.quit()
	       
	    else -- No
	       submenu = "pausemenu"
	       cursorPos = 0
	    end
	    
	 elseif submenu == "options" then --"Options"
	    
	    if cursorPos == 0 then --"Audio options"
	       submenu = "audio"
	       
	    elseif cursorPos == 1 then --"Keyboard options"
	       submenu = "controls"
	       cursorPos = 0
	       
	    elseif cursorPos == 2 then --"Toggle fullscreen"
	       if love.window.getFullscreen() then
		  love.window.setMode(800,600, {resizable = false, fullscreen = false , vsync = true} )
	       else
		  love.window.setMode(800,600, {resizable = false, fullscreen = true, vsync = true } )
	       end
	       
	    else --"Back"
	       submenu = prevmenu
	       cursorPos = 0
	    end
	    
	 elseif submenu == "controls" then --"Keyboard options"
	    
	    if cursorPos < 11 then --If the cursor is on a key, change it.
	       gamestate = "changekey"
	       
	    elseif cursorPos == 11 then --"Reset to defaults"
	       resetKeys()
	       TEsound.play("assets/audio/meow.wav", "meow")
	       
	    elseif cursorPos == 12 then --"Save changes"
	       applyKeys()
	       TEsound.play("assets/audio/meow.wav", "meow")
	       
	    elseif cursorPos == 13 then --"Back". don't change the cursor pos because it'll change by itself
	       submenu = prevmenu
	    end
	    
	 elseif submenu == "audio" then --"Audio options"
	    
	    if cursorPos < 3 then --If the cursor is on a volume option, change it
	       gamestate = "changekey"
	       
	    elseif cursorPos == 3 then --"Reset to defaults"
	       resetVolume()
	       TEsound.play("assets/audio/meow.wav", "meow")
	       
	    elseif cursorPos == 4 then --"Save changes"
	       applyOptions()
	       TEsound.play("assets/audio/meow.wav", "meow")
	       
	    else --"Back"
	       submenu = "options"
	    end
	    
	 elseif submenu == "gameover" then --"Game over :/"
	    
	    if cursorPos == 0 then --"Load game"
	       prevmenu = "gameover"
	       submenu = "loadmenu"
	       
	    elseif cursorPos == 1 then --"Back to main menu"
	       submenu = "main"
	       cursorPos = 0
	       
	    elseif cursorPos == 2 then --"Quit game"
	       love.event.quit()
	       
	    end
	 end
      end
      
   elseif gamestate == "play" then --"If the player is playing and is not interrupted by another gamestate

      if key == menukey then --Bring up pause menu
	 gamestate = "menu"
	 submenu = "pausemenu"
	 TEsound.pause("music")
	 unsaved = "true"
	 
      elseif key == pausekey then --Halt game and show "PAUSE" in the scren
	 gamestate = "pause"
	 
      elseif key == interactkey then --Interract with an NPC or an item
	 message = player[cp]:interact( mapi[ player[cp].mapkey ].n, player, cp )
	 if message then
	    gamestate = "message"
	 end
	 
      elseif key == switchkey then --Switch the current player (cp)
	 if player[ cp-1 ] or player[ cp+1 ] then
	    gamestate = "switchfadeout"
	    fadetimer = 0.5
	 end
      end
      
   elseif gamestate == "pause" then --If you press any key when it's paused, it'll play
      gamestate = "play"

   --If you press any key when the menu is done, it'll close the menu
   elseif gamestate == "message" then

      --Sends the key to the message function, continues game if done
      if message:keypressed( key, gamestate, player, map.n, cp ) then
	 message = nil
	 gamestate = "play"
      end
   end
end

--Update
function love.update(dt) --dt is dt=1 is 1 second
   if gamestate == "play" then
      debugvar = player[1].state
   end
   Monocle.update()
   
   ttimer = ttimer+dt --Increases the global timer by delta time.
   math.randomseed( ttimer ) --Change the seed to the global timer

   if gamestate == "play" or gamestate == "message" or gamestate == "fadeout" or gamestate == "fadein" or gamestate == "dead" or gamestate == "pause" or gamestate == "switchfadein" or gamestate == "switchfadeout" then
      updateWorld( dt )
   end

   if gamestate == "play" then --If the game is playing
      updatePlay( dt )

   elseif gamestate == "dead" then --If the player is dead, do a short fade anim
      
      updateDead( dt )
      
   elseif gamestate == "menu" then --All this does is make sure the cursor stays on the options.
      updateMenu( dt )

      --Fade the screen to black and then changes the map
   elseif gamestate == "fadeout" or gamestate == "fadein" or gamestate == "switchfadein" or gamestate == "switchfadeout" then
      updateFade( dt )

   elseif gamestate == "message" then --If drawing a message
      updateMessage( dt )
      
   end

   if gamestate == "play" or gamestate == "message" or gamestate == "fadeout" or gamestate == "fadein" or gamestate == "dead" or gamestate == "pause" or gamestate == "switchfadein" or gamestate == "switchfadeout" then
      updateDraw( dt )
   end

   updateAudio( dt )
end

function love.draw() --800x600

   --Zoom in 4x, making the res technically res 200x150, (but the screen will scroll smoother than that because scrolling 1 pixel at a time is ugly)
   love.graphics.scale(4,4)

   --Draws the world if in any of these states
   if gamestate == "play" or gamestate == "message" or gamestate == "fadeout" or gamestate == "fadein" or gamestate == "dead" or gamestate == "pause" or gamestate == "switchfadein" or gamestate == "switchfadeout" then
      drawGame()
      --The game is in both these states if in menu
   elseif gamestate == "menu" or gamestate == "changekey" then 
      drawMenu()
   end
end
