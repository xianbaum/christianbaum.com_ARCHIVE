--Global functions used in various places in the code

--round to nearest
function round(number)
   if number >= 0 then
      return math.floor(number+.5)
   end
   return math.ceil(number-.5)
end

--Returns true if a box is inside another box
function isColliding( x1, y1, w1, h1, x2, y2, w2, h2)
   return x1 < x2+w2 and
      x2 < x1+w1 and
      y1 < y2+h2 and
      y2 < y1+h1
end

--creates a global snow table or resets it
function createSnow( drawX, drawY ) 
   snow = {}
   for i=0,600 do
      snow[i] = Snow.create( drawX, drawY ) 
   end
end

--Called while loading a map, sets the global map, either 0 or 1
function createMap( number, startx, starty, playerNumber ,currentPlayer )
   local playerNumber = playerNumber or 0
   local map = sti.new("assets/maps/1/untitled")--..number.."/map")
   table.insert( mapi, MapInfo.create( number, startx, starty, map:initWorldCollision() ))
   return map
end

--This one is pretty straightforward. These are global keys
function resetKeys()
   upkey = "up"
   downkey = "down"
   leftkey = "left"
   rightkey = "right"
   actionkey = " "
   interactkey = "e"
   runkey = "lshift"
   switchkey = "tab"
   acceptkey = "return"
   pausekey = "p"
   menukey = "escape"
end

--"meow" is menu volume, defines the defaults considered by the game
function resetVolume() --These are global volumes
   sfxvolume = 100
   musicvolume = 100
   menuvolume = 50
   TEsound.volume("meow", menuvolume/100 )
   TEsound.volume("sfx", sfxvolume/100)
   TEsound.volume("music", musicvolume/100)
end

--Saves the current keybinds to keys.lua in the save directory
function applyKeys()
   
   --visit file
   local file = love.filesystem.newFile( 'keys.lua' )
   file:open("w")
   
   --Writes
   local success = file:write( 'upkey = "'..upkey..'"\ndownkey = "'..downkey..'"\nleftkey = "'..leftkey..'"\nrightkey = "'..rightkey..'"\nactionkey = "'..actionkey..'"\ninteractkey = "'..interactkey..'"\nrunkey = "'..runkey..'"\nswitchkey = "'..switchkey..'"\nacceptkey = "'..acceptkey..'"\npausekey = "'..pausekey..'"\nmenukey = "'..menukey..'"')
   
   --Closes
   file:close()
   if not success then
      errorx = "Error saving key binds" --"errorx" is an error message to display to the player
   end
end

--Saves the current options to options.lua in the save directory directory
function applyOptions()
   
   --visits the file
   local file = love.filesystem.newFile( 'options.lua' )
   file:open("w")
   
   --Writes
   local success = file:write( 'menuvolume = '..menuvolume..'\nmusicvolume = '..musicvolume..'\nsfxvolume = '..sfxvolume..'\nstartInFullscreen = false' )
   
   --Closes
   file:close()
   if not success then
      errorx = "Error saving options" --"errorx" is an error message to display to the player
   end
end

--Sets everything up for a new game
function startNewGame( dontCreateMap  )

   --deletes the snow if from the main menu
   snow = nil

   timer = 0 --Game timer, only advances during certain states
   flags = {} --Global flags for the game
   message = nil --message is for drawing messages
   player = {}
   table.insert(player, NPC.create( 17, 80,2, 0, nil, nil, nil, 3 ))
   
   --setting first in table as current player. setting cp to 1 should be fine but... i dunno.
   for _ in ipairs(player) do
      cp = _
      break
   end
   
   mapi = {}

   gamestate = "play"

   prevmenu = "pausemenu" --For pausing the game.
   lastaudio = "" --For working with my music code
   for i=0, 9 do
      flags[i] = false --sets them to false
   end
   
   --This is used if this function is called from loading a game
   if not dontCreateMap then 
      TEsound.stop("all")
      map = createMap( 11 ) --if called from loadgame, this will be called elsewhere

      --set the scene
      
   end

   for _, p in pairs(player) do
      p:setMapNo( 11 )
   end

   Monocle.watch("Debugvar", function() return debugvar end )
end

--Saves a game to slot0.lua to slot9.lua in save directory
function saveGame( number )

   local flagString = "" --used as part of the save string
   local npcString = ""
   local playerString = ""
   --setting flagString
   for flagno, flag in pairs(flags) do
      if flag == true then
	 flag = "true"
      else
	 flag = "false"
      end
      flagString = flagString .."flags["..flagno.."] = "..flag.."\n"
   end
   
   --setting NPC String
   for mapno, map in pairs(mapi) do
      npcString = npcString.."m["..mapno.."] = {}\nm["..mapno.."].npc = {}\nm["..mapno.."].no = "..map.number.."\n"
      for npcno, npc in pairs(mapi[mapno].n ) do
	 local npccooldown = "true"
	 if npc.cooldown == false then
	    npccooldown = "false"
	 end
	 --For each NPC, this string is added to the save string
	 npcString = npcString.."m["..mapno.."].".."npc["..npcno.."] = {}\nm["..mapno.."].npc["..npcno.."].x = "..npc.x.."\nm["..mapno.."].npc["..npcno.."].y = "..npc.y.."\nm["..mapno.."].npc["..npcno.."].state = \""..npc.state.."\"\nm["..mapno.."].npc["..npcno.."].action_counter = "..npc.action_counter.."\nm["..mapno.."].npc["..npcno.."].cooldown = "..npccooldown.."\nm["..mapno.."].npc["..npcno.."].dir = \""..npc.dir.."\"\n"
      end
   end

   --setting player string
   for pno, p in pairs(player) do
      playerString = playerString.. "playersi["..pno.."] = {}\nplayersi["..pno.."].x = "..p.x.."\nplayersi["..pno.."].y = "..p.y.."\nplayersi["..pno.."].health = "..p.health.."\nplayersi["..pno.."].food = "..p.food.."\nplayersi["..pno.."].mapno ="..p.mapno.."\n"
   end
   
   --concatenate the strings
   local saveString = "cpt = "..cp.."\ntime = "..timer.."\nflags = {}\n"..flagString.."\nm = {}\n"..npcString.."\nplayersi = {}\n"..playerString
   
   --visiting file
   local file = love.filesystem.newFile( 'save'..number..'.lua' )
   file:open("w")

   --writes
   local success = file:write( saveString )

   --closes
   file:close()
   if not success then
      errorx = "Error saving :/"
   end

   --"unsaved" is used to give a warning dialog. In this case, it's false, so give no warning.
   unsaved = false
   return time
end

--Loads a file from the save directory
function loadGame( number)
   
   --Loads (it's already checked if the file exists so this should be okay)
   local savefile = love.filesystem.load( "save"..number..'.lua')

   --resets game vars, does not load a map
   startNewGame( true )
   
   --exit if broked
   if not savefile then
      errorx = true
      return 0
   end

   --execute 
   savefile()
   for _, playeri in pairs( playersi ) do
      if not player[_] then
	 player[_] = {}
      end
      player[_]:setFromSave( playeri.x, playeri.y, nil, nil, nil, nil, playeri.health, playeri.food, playeri.mapno )
      playeri = nil
   end

   timer = time
   for flagno, flag in pairs(flags) do
      flags[flagno] = flag
   end

   --sets npc and map values
   for num, mapt in pairs(m) do
      local map_actual = createMap( mapt.no, 0, 0, num )
      if num == cpt then
	 map = map_actual
      end
      for i, npci in pairs( mapt.npc ) do
	 if not mapi[num].n then
	    mapi[num].n = {}
	 end
	 mapi[num].n[i]:setFromSave( npci.x, npci.y, npci.state, npci.action_counter, npci.cooldown, npci.dir )
	 npcl = nil
      end
   end

   map = sti.new("assets/maps/map"..player[cpt].mapno)   
   cp = cpt
   
   --yay!
   gamestate = "fadein"

   --throwing away values
   cpt, npc, playersi, time, m = nil,nil,nil,nil,nil
end

--Gets the time from a file for load/save screens
function getTime(number)
   local l = love.filesystem.load( 'save'..number..'.lua', saveString)
   if not l then
      errorx = "Error loading :/"
      return 0
   end
   l()
   return time
end

--Gets the map key 
function getMapKey( keyToGet )
   for key, m in pairs( mapi ) do
      if m.number == keyToGet then
	 return key
      end
   end
   return 600
end

function drawGame()
   
   --Moves the map to the drawX and drwaY positions
   love.graphics.translate(round( drawX*2)/2,round( drawY*2)/2)

   --sets the draw range to the drawX and drawY positions
   map:setDrawRange(drawX, drawY, windowWidth/4, windowHeight/4 )

   --sets the color to the current color (normally 255,255,255 but does change)
   love.graphics.setColor(red,green,blue)

   --Draws the background map layers
   map:drawTileLayer("BG1")
   map:drawTileLayer("BG2")
   
   --Draws NPCs
   for _, map in pairs(mapi) do
      map:drawNPCs( player[cp].mapno )
   end
   
   --And then the player
   for _, p in pairs(player) do
      if _ ~= cp then
	 p:draw( player[cp].mapno )
      end
   end
   player[cp]:draw( player[cp].mapno )

   --Draws the foreground map layers
   map:drawTileLayer("FG1")
   map:drawTileLayer("FG2")
   
   --draws bg if bg lol
   if gamestate == "message" and message.scene then
      message.scene:drawBG( drawX, drawY)
   end
   
   --draw snow after player, before hud
   if snow then
      for i=0,600 do
	 snow[i]:draw(red, blue, green )
      end
   end

   if gamestate == "message" and message.scene then
      message.scene:drawFG( drawX, drawY )
   end
   
   --Draw HUD in front of snow
   if gamestate ~= "message" then
      player[cp]:drawHud( drawX, drawY)
   end
   
   --If the game has a message, draw it
   if gamestate == "message" then
      if message.scene and not message.scene.hidemessage or not message.scene then
	 message:draw(drawX, drawY, gamestate, textbox, dialogbox , cursor )
      end
      
   elseif gamestate == "pause" then --If the game is in the pause state, draw PAUSE
      love.graphics.setColor(0,0,0)--Draws a black PAUSE
      love.graphics.printf( "PAUSE~", 0-drawX, 70-drawY, windowWidth/4, "center" )
      love.graphics.setColor(255,255,255)--then a white PAUSE
      love.graphics.printf( "PAUSE~", 1-drawX, 71-drawY, windowWidth/4, "center" )
      love.graphics.setColor(255,255,255)	
   end

   Monocle.draw( -drawX, -drawY )
end

function drawMenu( dt )
   love.graphics.setColor(255,255,255)
   if submenu == "main" then --Draw main menu stuff
      love.graphics.draw( title, 30,15)
      love.graphics.print("Start game\nLoad game\nOptions\nQuit", 65, 90)
      love.graphics.draw( cursor, 60, 90+cursorPos*8)

      if snow then
	 for i=0, 600 do --Main menu has snoowww
	    snow[i]:draw()
	 end
      end

   elseif submenu == "loadmenu" then --Load menu stuff
      love.graphics.print("Load: "..errorx,0,0)

      for i = 0, 9 do --Print slots with their times
	 local loadtext = " (Empty)"


	 if love.filesystem.exists( "save"..i..".lua" ) then
	    local sec = getTime( i )
	    loadtext = " ".. math.floor( sec / 3600 ) .. ":" .. math.floor(sec /60 % 60 ) .. ":" ..math.floor( sec % 60 )
	 end

	 --Print the slot
	 love.graphics.print("Slot"..i..":"..loadtext..errorx,8,8+i*8)
      end

      --Prints the other parts of the menu and then the cursor
      love.graphics.print("Back ~", 8, 88 )
      love.graphics.draw( cursor, 2, 8+cursorPos*8)
      
   elseif submenu == "savemenu" then --Save menu text drawing
      love.graphics.print("Save:"..errorx,0,0)

      for i = 0, 9 do --Print slots with their times
	 local loadtext = " (Empty)"


	 --If it exists, grab the time on the savefile and format it
	 if love.filesystem.exists( "save"..i..".lua" ) then
	    local sec = getTime( i )
	    loadtext = " ".. math.floor( sec / 3600 ) .. ":" .. math.floor( sec / 60 % 60 ) .. ":" ..math.floor( sec % 60 )
	 end
	 
	 --Print the slot
	 love.graphics.print("Slot"..i..":"..loadtext..errorx,8,8+i*8)
      end

      --Prints the other parts
      love.graphics.print("Back ~", 8, 88 )
      love.graphics.draw( cursor, 2, 8+cursorPos*8)

   elseif submenu == "pausemenu" then --Pause menu
      love.graphics.printf("Pause", 0, 50, windowWidth/4, "center")
      love.graphics.print("Resume game\nSave game\nLoad game\nOptions\nExit to main menu\nQuit", 65, 80)
      love.graphics.draw( cursor, 60, 80+cursorPos*8)

   elseif submenu == "reallyquit" then --"Really quit?" menu
      love.graphics.printf("Really quit? Unsaved data will be lost.", 0, 50, windowWidth/4, "center")
      love.graphics.print("Yes\nNo", 65, 80)
      love.graphics.draw( cursor, 60, 80+cursorPos*8)

   elseif submenu == "reallyexit" then --"Really exit?" mneu
      love.graphics.printf("Really exit? Unsaved data will be lost.", 0, 50, windowWidth/4, "center")
      love.graphics.print("Yes\nNo", 65, 80)
      love.graphics.draw( cursor, 60, 80+cursorPos*8)

   elseif submenu == "gameover" then --Game over menu
      love.graphics.printf("Game over :/", 0, 50, windowWidth/4, "center")
      love.graphics.print("Load game\nExit to main menu\nQuit", 65, 80)
      love.graphics.draw( cursor, 60, 80+cursorPos*8)

   elseif submenu == "options" then --Options menu
      love.graphics.printf("Options"..errorx, 0, 50, windowWidth/4, "center")
      love.graphics.print("Audio options\nKeyboard options\nToggle Fullscreen\nBack", 65, 80)
      love.graphics.print("Created by Christian Michael Baum\nMade with love ~ (and also Love2D)")
      love.graphics.draw( cursor, 60, 80+cursorPos*8)

   elseif submenu == "controls" then --Menu to rebind keys

      --Prints a different message depending on state
      local messagek = ""
      if gamestate == "changekey" then
	 messagek = "(press any key to change)"
      else
	 messagek = "(blank is space key)"
      end

      --Prints each control, option and cursor
      love.graphics.print("Keyboard Options: "..messagek..errorx,0,0)
      love.graphics.print("Up: "..upkey.."\nDown: "..downkey.."\nLeft: "..leftkey.."\nRight: "..rightkey.."\nRun: "..runkey.."\nInteract: "..interactkey.."\nAction: "..actionkey.."\nSwitch Character: "..switchkey.."\nAccept/OK: "..acceptkey.."\nPause: "..pausekey.."\nMenu: "..menukey.."\nReset to default\nSave changes\nBack",8,8)
      love.graphics.draw( cursor, 2, 8+cursorPos*8)
      
   elseif submenu == "audio" then --Menu to change volume

      --Prints a different message depending on state
      local messagek = ""
      if gamestate == "changekey" then
	 messagek = "\nUse movement keys to adjust."
      else
	 messagek = ""
      end

      --Prints each volume, option and cursor
      love.graphics.printf("Audio options"..messagek, 0, 50, windowWidth/4, "center")
      love.graphics.print("Menu volume: < "..menuvolume.." >\nMusic volume: < "..musicvolume.." >\nSFX volume: < "..sfxvolume.." >\nReset to default\nSave changes\nBack", 65, 80)
      love.graphics.draw( cursor, 60, 80+cursorPos*8)

   end
end


function updateDraw( dt )
   drawX = -player[cp].x+(windowWidth/8)-4
   drawY = -player[cp].y+(windowHeight/8)-4

   --Then sets the bounds of them to the map
   if drawX > 0 then drawX = 0 end
   if drawY > 0 then drawY = 0 end
   if drawX - (windowWidth/4) < -mapi[ player[cp].mapkey ].width*16 then
      drawX = -mapi[ player[cp].mapkey ].width*16 + windowWidth/4 end
   if drawY - (windowHeight/4) < -mapi[ player[cp].mapkey ].height*16 then
      drawY = -mapi[ player[cp].mapkey].height*16 + windowHeight/4 end

   --update snow/create snow if it doesn't exist and map number is 1
   if mapi[ player[cp].mapkey ].number == 11 or gamestate == "message" and message.scene and message.scene.hasSnow then
      if not snow then
	 createSnow( -drawX, -drawY)
      end
      for i=0,600 do
	 snow[i]:update( dt, -drawX, -drawY, windowWidth, windowHeight )
      end
   else
      snow = nil
   end
end

function updatePlay( dt )
   --Sets the RGB to white in this state, might change later in game
   red,blue,green = 255,255,255

   --If the player goxes through a door, maptemp will not be nil.

   --Updates the player
   for _, p in pairs(player) do

      --If the player is the currently selected player, then cp is true
      --if is the current player, get door values
      if _ == cp then
	 mapno, startx, starty = p:updatePlayer(dt, mapi[p.mapkey], player, true)

	 --If not, just update
      else
	 p:updatePlayer(dt, mapi[p.mapkey], player, false)
      end

      --Updates the animation frames
      p:updateAnim( dt, mapi[p.mapkey].number )
   end

   --Updates the map info
   for _, mapt in pairs(mapi) do

      --Update the NPCs in the map
      mapt:updateNPCs( dt, player, _ )
   end
   
   --Updates the sti map
   map:update( dt )

   --audio changes if newaudio is different than lastaudio
   newaudio = mapi[ player[cp].mapkey ].audio

   --If the player's health is 0 then gameover
   for _, p in pairs(player) do
      if p.health == 0 then
	 gamestate = "dead"
	 fadetimer = 2
	 TEsound.pause("music")
	 --TODO: play sound
	 break
      end
   end
   
   --If maptemp is not nill, then change then start the fade to move to next map
   if mapno then --If the player enters a door, "maptemp" will be true.
      gamestate = "fadeout"
      fadetimer = 0.5
   end
end

function updateWorld( dt )
   --Sets the in-use maps as used
   for _, p in pairs(player) do

      --First we get the map key
      p:setMapKey( getMapKey( p.mapno ) )
      
      --The map the player is in is used.
      mapi[ p.mapkey ]:setUsed( true )
   end
   
   --Checks if the map is used
   for _, mapt in pairs(mapi) do

      --If it is unused, then remove it from the list
      if not mapt.used then
	 mapt = nil
	 table.remove( mapi, _ )
	 break
      end

      --Will be set used again if the player is in the map
      if mapt then
	 mapt:setUsed( false )
      end
   end

   for _, p in pairs(player) do

      --First we get the map key

      p:setMapKey( getMapKey( p.mapno ) )
      
   end
   
   --Increase game timer if the game is not in any of these states
   if not gamestate ~= "pause" and not gamestate ~= "dead" then
      timer = timer + dt
   end
end

function updateDead( dt )
   fadetimer = fadetimer - dt --fade timer decreases each frame
   
   if fadetimer > 1.3 then --Fade colors 1
      red,green,blue = 255,0,0
      
   elseif fadetimer > 0.7 then --Fade colors 2
      red,green,blue = 144,0,0
      
   elseif fadetimer > 0 then --Fade colors 3
      red,green,blue = 0,0,0
      
   else --If fade < 0, then bring up the gameover screen and change the game state
      gamestate = "menu"
      submenu = "gameover"
      cursorPos = 0
      prevmenu = "main"
   end
end

function updateFade( dt )
   fadetimer = fadetimer - dt*2 --Increases the fade timer

   --If fade out, maptemp will have a value. If fade in, maptemp will be nil.
   if fadetimer >= 0.25 and gamestate == "fadeout" or fadetimer <= 0.25 and gamestate == "fadein" or fadetimer >= 0.25 and gamestate == "switchfadeout" or fadetimer <= 0.25 and gamestate == "switchfadein" then
      red,blue,green = 144,144,144 --Grey screen
   else
      red,blue,green = 0,0,0 --Black screen
   end
   
   --If the 1st fade is over, time to change map and start a new fade
   if fadetimer < 0 and gamestate == "fadeout" then
      player[cp]:set( mapi[ player[cp].mapkey ].startx, mapi[ player[cp].mapkey].starty) --Move player
      fadetimer = 0.5 --Reset fade timer
      map = createMap( mapno, nil, nil, cp)

      --resets snow position when going through a door
      snow = nil

      player[cp]:setMapNo( mapno )
      player[cp]:setMapKey( getMapKey( mapno ) )
      player[cp]:set( startx, starty )

      for _, p in pairs(player) do
	 if p.state == "following" or p.state == "following2" then
	    if p.target == cp then
	       p:setMapNo( mapno )
	       p:setMapKey( getMapKey( mapno ) )
	       p:set( startx, starty )
	    end
	 end
      end
      
      mapno = nil
      gamestate = "fadein"
      
   elseif fadetimer < 0 and gamestate == "fadein" then --If the 2nd fade is done, play the game again
      gamestate = "play"

      --Switchfade code
   elseif fadetimer < 0 and gamestate == "switchfadeout" then
      local tempCP = cp
      local cpNeedsChanged = false
      
      --switch the currentplayer
      for key in ipairs(player) do
	 if cpNeedsChanged then
	    cp = key
	    cpNeedsChanged = false
	 end
	 if key == tempCP then
	    cpNeedsChanged = true
	 end
      end
      
      if cpNeedsChanged then
	 for key in ipairs(player) do
	    cp = key
	    break
	 end
      end
      
      --If the player to switch to doesn't exist, loop back to 0
      if not player[cp] then
	 cp = 0
      end

      if player[cp].state == "following" or player[cp].state == "following2" then
	 if player[cp].target == tempCP then
	    player[tempCP]:setState( "following" )
	    player[tempCP]:setTarget( cp )
	 end
      end

      --resets snow position when switching character
      snow = nil

      --change map if need to
      map = sti.new("assets/maps/map".. player[cp].mapno)
      
      gamestate = "switchfadein"
      fadetimer = 0.5

   elseif fadetimer < 0 and gamestate == "switchfadein" then
      gamestate = "play"
   end
end

function updateMenu( dt )

   if submenu == "main" or submenu == "options" then --For example, the main menu has 4 options
      --buuuut in this case we'll also check if snow exists and create it.
      if not snow then
	 createSnow()
      end
      for i=0,600 do --And update it.
	 snow[i]:update( dt, 0, 0, windowWidth, windowHeight )
      end

      if cursorPos > 3 then cursorPos = 0 elseif cursorPos < 0 then cursorPos = 3 end
   else
      snow = nil
   end
   
   if submenu == "loadmenu" or submenu == "savemenu" then
      if cursorPos < 0 then cursorPos = 10 elseif cursorPos > 10 then cursorPos = 0 end
   elseif submenu == "pausemenu" then
      if cursorPos < 0 then cursorPos = 5 elseif cursorPos > 5 then cursorPos = 0 end
   elseif submenu == "reallyquit" or submenu == "reallyexit" then
      if cursorPos < 0 then cursorPos = 1 elseif cursorPos > 1 then cursorPos = 0 end
   elseif submenu == "gameover" then
      if cursorPos < 0 then cursorPos = 2 elseif cursorPos > 2 then cursorPos = 0 end
   elseif submenu == "controls" then
      if cursorPos < 0 then cursorPos = 13 elseif cursorPos > 13 then  cursorPos = 0 end
   elseif submenu == "audio" then
      if cursorPos < 0 then cursorPos = 5 elseif cursorPos > 5 then cursorPos = 0 end
   end
end

function updateMessage( dt )
      if message then --If a message exists, update it
	 message:update( dt, flags)
	 
      else --If not, play game
	 gamestate = "play"
      end
end

function updateScene( dt )
   if scene then --if scene exists, update
      scene:update( dt )

   else --If not, play game
      gamestate = "play"
   end
end

function updateAudio( dt )
   if newaudio and lastaudio ~= newaudio then -- Change audio if they do not match

      if music then -- Stops music
	 TEsound.stop("music")
      end

      --Then plays the new piece
      music = TEsound.playLooping("assets/audio/track"..newaudio..".mod", "music")

      --Then sets them together again
      lastaudio = newaudio
   end

   --Uh
   TEsound.cleanup()
end
