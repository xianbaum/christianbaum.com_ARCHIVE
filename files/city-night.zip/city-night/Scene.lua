Scene = {}
Scene.__index = Scene

function Scene.create( index )
   scene = {}

   scene.hasSnow = false

   --if it is not 0, then the scene has an image
   local bgno = 0
   local fgno = 0

   if index == 1 then
      scene.hasSnow = true
      bgno = 1
      fgno = 1
      scene.hidemessage = true

   elseif index == 2 then
      scene.hasSnow = true
      bgno = 1
      fgno = 2
      scene.hidemessage = true
   end

   --gets the image if either is not 0
   if bgno ~= 0 then
      scene.bg = love.graphics.newImage("assets/sprites/bg"..bgno..".png")
      scene.bg:setFilter( "nearest" )
   end
   if fgno ~= 0 then
      scene.fg = love.graphics.newImage("assets/sprites/fg"..fgno..".png")
      scene.fg:setFilter( "nearest" )
   end

   return setmetatable( scene, Scene )
end

function Scene.update(dt)
end

function Scene:drawBG( drawX, drawY )
   if self.bg then
      love.graphics.draw( self.bg, -drawX, -drawY )
   end
end

function Scene:drawFG()
   if self.fg then
      love.graphics.draw( self.fg, -drawX, -drawY )
   end
end
