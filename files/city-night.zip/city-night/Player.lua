Player = {}
Player.__index = Player

-- Player Functions----------------------------------------------------------------------

function Player:setFromLoad( x, y, health, food )
   self.x = x
   self.y = y
   self.health = health
   self.food = food
end


