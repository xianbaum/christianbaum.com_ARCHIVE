MapInfo = {}
MapInfo.__index = MapInfo

-- MapInfo Functions ---------------------------------------------------------------------------------------

function MapInfo.create( number, startx, starty, collision )
   local mapinfo = {}

   --Doooooors (actually I think the term is exits)
   function createDoor( tilex, tiley, mapno, to_tilex, to_tiley )
      local d = {}
      d.x = tilex*16
      d.y = tiley*16
      d.mapno = mapno
      d.tox = to_tilex*16
      d.toy = to_tiley*16
      return d
   end
   --loads and execuytes the info file
   local infofile = love.filesystem.load( "assets/maps/"..number..'/info.lua')
   mapinfo = infofile()

   --setting optiosn
   mapinfo.startx = startx
   mapinfo.starty = starty
   mapinfo.number = number
   mapinfo.c = collision
   mapinfo.used = true
   mapinfo.updated = false


   
   --set the mapno for these npcs
   for _, npc in pairs(mapinfo.n) do
      npc:setMapNo( mapinfo.number )
   end
   
   return setmetatable( mapinfo, MapInfo)
end

function MapInfo:updateNPCs( dt, player, cp )
   for _, npc in ipairs(self.n) do
      npc:update( dt, self, player, cp)
      if npc.image then
	 npc:updateAnim( dt )
      end
   end
   self.update = true
end

function MapInfo:drawNPCs( mapno )
   for _, npc in ipairs(self.n) do
      npc:draw( mapno )
   end
end

function MapInfo:setUsed( isUsed )
   self.used = isUsed
end
