Event = {}
Event.__index = Event

--If X or Y are nil, then 
function Event.create( x, y, required_flag )
   
end
