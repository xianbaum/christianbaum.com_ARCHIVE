mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 10
mapinfo.height = 20
mapinfo.audio = 2
table.insert( mapinfo.d, createDoor( 6, 17, 3, 9,12 ))
table.insert( mapinfo.d, createDoor( 6, 1, 5, 5, 7 ))
table.insert( mapinfo.n, NPC.create( 2, 3, 5, 2 ) )
table.insert( mapinfo.n, NPC.create( 2, 3, 9, 2 ) )
table.insert( mapinfo.n, NPC.create( 2, 3, 13, 2 ) )
table.insert( mapinfo.n, NPC.create( 2, 3, 15, 2 ) )
return mapinfo
