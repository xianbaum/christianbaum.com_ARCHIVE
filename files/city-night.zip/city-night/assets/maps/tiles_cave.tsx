<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles_cave" tilewidth="16" tileheight="16">
 <image source="tiles_cave.png" width="64" height="64"/>
 <tile id="4">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
</tileset>
