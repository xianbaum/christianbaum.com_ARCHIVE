mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width= 10
mapinfo.height=10
mapinfo.audio = 2
table.insert( mapinfo.d, createDoor( 5,8, 4, 6, 2 ) )
table.insert( mapinfo.n, NPC.create( 6, 5, 3, 5 , 3  ))
table.insert( mapinfo.n, NPC.create( 1, 2, 4, 4 ) )
table.insert( mapinfo.n, NPC.create( 1, 7, 4, 4 ) )
return mapinfo
