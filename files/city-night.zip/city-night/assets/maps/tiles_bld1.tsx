<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles_bld1" tilewidth="16" tileheight="16">
 <image source="tiles_bld1.png" width="128" height="128"/>
 <tile id="0">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
</tileset>
