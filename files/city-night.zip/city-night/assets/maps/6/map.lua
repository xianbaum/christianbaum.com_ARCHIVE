return {
  version = "1.1",
  luaversion = "5.1",
  orientation = "orthogonal",
  width = 10,
  height = 10,
  tilewidth = 16,
  tileheight = 16,
  properties = {},
  tilesets = {
    {
      name = "tiles_cave",
      firstgid = 1,
      filename = "tiles_cave.tsx",
      tilewidth = 16,
      tileheight = 16,
      spacing = 0,
      margin = 0,
      image = "tiles_cave.png",
      imagewidth = 64,
      imageheight = 64,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      tiles = {
        {
          id = 4,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 5,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 6,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 11,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 15,
          properties = {
            ["collidable"] = "true"
          }
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "Tile Layer 1",
      x = 0,
      y = 0,
      width = 10,
      height = 10,
      visible = true,
      opacity = 1,
      properties = {},
      encoding = "lua",
      data = {
        16, 16, 5, 6, 6, 6, 6, 7, 16, 16,
        16, 5, 12, 12, 12, 12, 12, 12, 7, 16,
        16, 12, 9, 10, 10, 10, 10, 11, 12, 16,
        16, 9, 1, 1, 1, 1, 1, 1, 11, 16,
        16, 1, 1, 1, 1, 1, 1, 1, 1, 16,
        16, 1, 1, 1, 1, 1, 1, 1, 1, 16,
        16, 1, 1, 1, 1, 1, 1, 1, 1, 16,
        16, 13, 1, 1, 1, 1, 1, 1, 15, 16,
        16, 16, 13, 14, 14, 3, 14, 15, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16, 16, 16
      }
    }
  }
}
