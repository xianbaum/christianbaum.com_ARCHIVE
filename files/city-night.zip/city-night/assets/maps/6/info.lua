mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 10
mapinfo.height = 10
mapinfo.audio = 2
table.insert( mapinfo.d, createDoor( 5, 8, 1, 69, 95 ))
table.insert( mapinfo.n, NPC.create( 6, 5, 3, 5, 4 ) )
return mapinfo

