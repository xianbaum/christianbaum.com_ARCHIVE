return {
  version = "1.1",
  luaversion = "5.1",
  orientation = "orthogonal",
  width = 20,
  height = 13,
  tilewidth = 16,
  tileheight = 16,
  properties = {},
  tilesets = {
    {
      name = "tiles_bld1",
      firstgid = 1,
      filename = "../tiles_bld1.tsx",
      tilewidth = 16,
      tileheight = 16,
      spacing = 0,
      margin = 0,
      image = "../tiles_bld1.png",
      imagewidth = 128,
      imageheight = 128,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      tiles = {
        {
          id = 0,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 2,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 4,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 8,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 10,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 11,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 19,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 20,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 21,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 24,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 27,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 42,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 48,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 57,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 58,
          properties = {
            ["collidable"] = "true"
          }
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "Tile Layer 1",
      x = 0,
      y = 0,
      width = 20,
      height = 13,
      visible = true,
      opacity = 1,
      properties = {},
      encoding = "lua",
      data = {
        12, 12, 12, 12, 12, 20, 25, 25, 25, 25, 25, 25, 12, 12, 12, 12, 12, 12, 12, 12,
        12, 12, 12, 12, 20, 25, 25, 25, 25, 25, 25, 3221225492, 12, 20, 25, 25, 25, 12, 12, 12,
        12, 12, 12, 20, 25, 1, 2, 2, 2, 2, 3, 12, 20, 25, 27, 25, 25, 12, 12, 12,
        12, 12, 20, 25, 1, 2, 2, 2, 2, 3, 12, 20, 25, 1, 2, 2, 3, 12, 12, 12,
        12, 20, 25, 1, 2, 2, 2, 2, 2, 25, 25, 25, 1, 2, 2, 3, 12, 12, 12, 12,
        12, 25, 1, 2, 2, 2, 2, 2, 2, 25, 25, 1, 2, 2, 3, 12, 12, 12, 12, 12,
        12, 1, 43, 3, 20, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 12,
        12, 2, 3, 20, 25, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 12, 12,
        12, 3, 20, 25, 1, 2, 2, 2, 59, 57, 58, 2, 2, 2, 2, 2, 3, 12, 12, 12,
        12, 20, 25, 1, 2, 2, 2, 2, 43, 43, 2, 2, 2, 2, 2, 3, 12, 12, 12, 12,
        12, 25, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 12, 12, 12, 12, 12,
        12, 1, 2, 2, 2, 2, 2, 2, 2, 60, 2, 2, 2, 3, 12, 12, 12, 12, 12, 12,
        12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12
      }
    }
  }
}
