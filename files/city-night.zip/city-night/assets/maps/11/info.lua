mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 500
mapinfo.height = 500
mapinfo.audio = 1
table.insert( mapinfo.d, createDoor(2, 5, 12, 14, 3 ) )

table.insert( mapinfo.n, NPC.create( nil, 8, 1, 0, 3 ) )

return mapinfo
