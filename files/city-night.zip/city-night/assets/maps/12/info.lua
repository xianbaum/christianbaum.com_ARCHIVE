mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 19
mapinfo.height = 12
mapinfo.audio = 12
table.insert( mapinfo.d, createDoor(14, 2, 11, 3, 5 ) )
snow = true
table.insert( mapinfo.n, NPC.create( nil, 8, 1, 0, 3 ) )

return mapinfo
