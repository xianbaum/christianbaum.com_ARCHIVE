mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 45
mapinfo.height = 45
mapinfo.audio = 2
table.insert( mapinfo.d, createDoor( 20, 43, 2, 16,1 ))
table.insert( mapinfo.d, createDoor( 9, 11, 4, 6,16 ))
table.insert( mapinfo.n, NPC.create( 2, 24, 35, 1 ) )
table.insert( mapinfo.n, NPC.create( 2, 23, 36, 2 ) )
return mapinfo
