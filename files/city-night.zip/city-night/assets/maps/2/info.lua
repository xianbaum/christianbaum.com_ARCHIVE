mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 45
mapinfo.height = 15
mapinfo.audio = 2
table.insert( mapinfo.d, createDoor(37, 13, 1,  58, 90 ) )
table.insert( mapinfo.d, createDoor(3, 9, 1, 43,90))
table.insert( mapinfo.d, createDoor(16, 0, 3, 20,42))
return mapinfo
