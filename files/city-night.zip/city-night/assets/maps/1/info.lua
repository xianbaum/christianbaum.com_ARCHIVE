mapinfo = {}
mapinfo.n = {}
mapinfo.d = {}

mapinfo.width = 100
mapinfo.height = 100
mapinfo.audio = 1
table.insert( mapinfo.d, createDoor(58, 89, 2, 37, 12 ) )
table.insert( mapinfo.d, createDoor(43, 89, 2, 3, 8))
table.insert( mapinfo.d, createDoor( 69, 94, 6, 5, 7 ))
return mapinfo
