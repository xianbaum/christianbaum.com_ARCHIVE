return {
  version = "1.1",
  luaversion = "5.1",
  orientation = "orthogonal",
  width = 20,
  height = 10,
  tilewidth = 16,
  tileheight = 16,
  properties = {},
  tilesets = {
    {
      name = "tiles_bld1",
      firstgid = 1,
      filename = "tiles_bld1.tsx",
      tilewidth = 16,
      tileheight = 16,
      spacing = 0,
      margin = 0,
      image = "tiles_bld1.png",
      imagewidth = 64,
      imageheight = 128,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      tiles = {
        {
          id = 7,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 8,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 9,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 11,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 12,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 13,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 15,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 17,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 20,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 22,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 24,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 25,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 26,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 28,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 29,
          properties = {
            ["collidable"] = "true"
          }
        },
        {
          id = 30,
          properties = {
            ["collidable"] = "true"
          }
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "Tile Layer 1",
      x = 0,
      y = 0,
      width = 20,
      height = 10,
      visible = true,
      opacity = 1,
      properties = {},
      encoding = "lua",
      data = {
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 12, 13, 19, 13, 13, 19, 13, 13, 13, 13, 13, 19, 13, 13,
        8, 8, 8, 8, 8, 12, 13, 13, 13, 13, 19, 13, 13, 15, 13, 13, 13, 13, 19, 13,
        8, 8, 8, 8, 12, 13, 1, 31, 29, 29, 29, 30, 2, 2, 31, 29, 29, 29, 30, 3,
        8, 8, 8, 12, 13, 1, 31, 29, 29, 29, 30, 2, 2, 31, 29, 29, 29, 30, 3, 8,
        8, 8, 12, 19, 1, 31, 29, 29, 29, 30, 2, 2, 31, 29, 29, 29, 30, 3, 8, 8,
        8, 12, 13, 1, 31, 29, 29, 29, 30, 2, 2, 31, 29, 29, 29, 30, 3, 8, 8, 8,
        8, 19, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 8, 8, 8, 8,
        8, 1, 2, 2, 2, 2, 2, 2, 32, 2, 2, 2, 2, 2, 3, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8
      }
    },
    {
      type = "tilelayer",
      name = "Tile Layer 2",
      x = 0,
      y = 0,
      width = 20,
      height = 10,
      visible = true,
      opacity = 1,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    }
  }
}
