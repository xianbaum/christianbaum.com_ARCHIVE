Message = {}
Message.__index = Message

-- Message Functions

--Message is depenent on the messageno
function Message.create( no, index)

   local msg = {}


   --DIALOGS------------------------------------------------------------------------------------------------
   if no == 0 then
      msg.text = "What should we do?"
      msg.o = {}
      table.insert( msg.o, "Nothing" )
      table.insert( msg.o, "Split up" )
   elseif no == 1 then
      msg.text = "What should we do?"
      msg.o = {}
      table.insert( msg.o, "Nothing" )
      table.insert( msg.o, "Join up" )
   elseif no == 2 then
      msg.text = "Nothing."
   elseif no == 3 then
      msg.text = "(Look out the window?)"
      msg.o = {}
      table.insert( msg.o, "Yes." )
      table.insert( msg.o, "No." )
   elseif no == 4 then
      msg.text = "Leave me alone in here!"
   end
   
   --vars that every message uses
   msg.no = no
   msg.subtext = ""
   msg.current_letter = 0
   msg.rush = false
   msg.cursorpos = 0
   msg.index = index
   
   return setmetatable( msg, Message)
end

function Message:update( dt, flags )

   --update the letter count
   self.current_letter = self.current_letter + 18*dt

   --If it's done prinitng text
   if math.floor(self.current_letter) >= self.text:len() then

      --Set the flag
      if self.flags then
	 flags[ self.flag ] = true
      end

      --If there's a sound to play, play it
      if self.sound and not self.soundplayed then
	 sound = love.audio.newSource("assets/audio/"..self.sound) or nil 
	 sound:play()
	 self.soundplayed = true
      end
   end

   --If there's another letter, play the "doot" sound
   if math.floor(self.current_letter) ~= self.subtext:len() and self.current_letter < self.text:len() then
      TEsound.play(doot, "sfx")
   end
   --set the subtext
   self.subtext = self.text:sub(0, math.floor(self.current_letter))

   --If the player is holding down a button, increase the current letter by 1
   if self.rush then
      if love.keyboard.isDown( actionkey ) or love.keyboard.isDown( interactkey) or love.keyboard.isDown( acceptkey) then
	 self.current_letter = self.current_letter + 1
      end
   end
end

function Message:draw( drawx, drawy, gamestate, textbox, dialogbox, cursor )

   --prints the box
   love.graphics.draw( textbox, round(20-drawx), round(90-drawy) )

   --print the subtext
   love.graphics.printf( self.subtext, round(28-drawx), round(98-drawy), 147)

   --if it's done, print the cursor if there is no options
   if self.current_letter >= self.text:len() and math.floor(self.current_letter/4) % 2 == 1 and not self.o then
       love.graphics.draw( cursor, round(172-drawx), round(140-drawy), math.rad(90) )
   end


   --Prints the dialog options, if they exist
   if self.o and math.floor(self.current_letter) >= self.text:len() then
      local offset = 0      

      --draw optiosn
      for _, option in pairs(self.o) do
	 love.graphics.draw( cursor, round(4-drawx), round(8+self.cursorpos*8-drawy))
	 love.graphics.setColor(0,0,0)
	 love.graphics.print( option, round(8-drawx), round(8-drawy+offset) )
	 love.graphics.setColor(255,255,255)
	 love.graphics.print( option, round(9-drawx), round(9-drawy+offset) )
	 offset = offset+8
      end
   end
end

function Message:changeNPCState( npc, state )
   NPC:changeState( state )
end
				 
function Message:keypressed( key, gamestate, p, n, cp )
   --have to press a key before you can rush the text
   self.rush = true

   --If a key is pressed, the message is done and there are no optiosn, then quit
   if self.current_letter >= self.text:len() and not self.o then
      return true
   elseif self.o and self.current_letter >= self.text:len() then
      if key == downkey then
	 self.cursorpos = self.cursorpos + 1
	 TEsound.play(doot, "meow")
      elseif key == upkey then
	 self.cursorpos = self.cursorpos - 1
	 TEsound.play(doot, "meow")
      end

      if self.cursorpos < 0 then
	 self.cursorpos = table.getn( self.o )-1
      elseif self.cursorpos > table.getn( self.o )-1 then
	 self.cursorpos = 0
      end
      
      if key == acceptkey or key == interactkey or key == actionkey then
	 self:processOption( p, n, cp)
      end
   end
   
   return false
end

function Message:processOption( p, n, cp)

   self.subtext = ""
   self.current_letter = 0
   self.rush = false
   self.o = nil
   self.text = ""
   
   if self.no == 0 then
      if self.cursorpos == 0 then
	 self.text = "I see."
      elseif self.cursorpos == 1 then
	 self.text = "Okay..."
	 for _, player in pairs(p) do
	    if player.target == cp and player.state == "following" or
	    player.state == "following2" and player.target == cp then
	       player:setState( "standing" )
	    end
	 end
      end
      
   elseif self.no == 1 then
      if self.cursorpos == 0 then
	 self.text = "I see."
      elseif self.cursorpos == 1 then
	 self.text = "Okay. Let's stick together."
	 p[self.index]:setState( "following" )
	 p[self.index]:setTarget( cp )
      end
      
   elseif self.no == 3 then
      if self.cursorpos == 0 then
	 self.scene = Scene.create( 1 )
	 self.o = {}
	 table.insert( self.o, "" ) --blank because i'm just working around my code
	 self.no = 1000
      else
	 self.text = "(Someone's at the door.)"
      end
      
   elseif self.no == 1000 then
      self.scene = nil
      self.text = "(Someone's at the door.)"
      
   elseif self.no == 1001 then
      self.text = "Great! My address is 429 East Division Street."
      self.o = {}
      table.insert( self.o, "Do you want soda with that?")
      self.no = 1002
   elseif self.no == 1002 then
      self.text = "No, no. Had to pee out a rock a few years ago and after that I said \"No more soda!\""
      self.o = {}
      table.insert( self.o, "Okay, it'll be about 30 minutes. Bye!" )
      self.no = 1003
   elseif self.no == 1003 then
      self.text = "OK bye!"
   end
   self.cursorpos = 0
end
